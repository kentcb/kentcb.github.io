﻿using System;
using System.Windows;

namespace DoEvents
{
	public partial class Window1 : Window
	{
		public Window1()
		{
			InitializeComponent();
		}

		private void _click(object sender, EventArgs e)
		{
			//update the label
			_label.Content = DateTime.Now.ToString("dd/MM/yyyy HH:mm:ss.fff");

			if (_checkBox.IsChecked.GetValueOrDefault(false))
			{
				//without calling DoEvents, there will be a delay before the text is updated
				Application.Current.DoEvents();
			}

			//simulate a long-running operation on the UI thread, without giving the Dispatcher time to process the change to the label's text
			System.Threading.Thread.Sleep(2000);
		}
	}
}