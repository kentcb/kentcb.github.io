﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Windows.Data;
using Data;
using RangeCollectionViewDemo.Model;
using RangeCollectionViewDemo.Services;
using RangeCollectionViewDemo.Controls;

namespace RangeCollectionViewDemo.ViewModels
{
    public sealed class ChartViewModel : ViewModel
    {
        private readonly IQuoteService quoteService;
        private readonly IEnumerable<TickerViewModel> tickers;
        private ICollectionView allDataPoints;
        private RangeCollectionView zoomedDataPoints;
        private TickerViewModel selectedTicker;
        private BackgroundWorker getQuotesWorker;
        private double minimum;
        private double maximum;
        private int zoomStartIndex;
        private int zoomEndIndex;

        public ChartViewModel()
        {
            // would normally get this through DI
            this.quoteService = new QuoteService();

            this.tickers = from ticker in this.quoteService.Tickers
                           select new TickerViewModel(ticker.Symbol, ticker.CompanyName);
        }

        public IEnumerable<TickerViewModel> Tickers
        {
            get { return this.tickers; }
        }

        public ICollectionView AllDataPoints
        {
            get { return this.allDataPoints; }
            private set
            {
                this.allDataPoints = value;
                this.OnPropertyChanged("AllDataPoints");
            }
        }

        public ICollectionView ZoomedDataPoints
        {
            get { return this.zoomedDataPoints; }
            private set
            {
                this.zoomedDataPoints = value as RangeCollectionView;
                this.OnPropertyChanged("ZoomedDataPoints");
            }
        }

        public TickerViewModel SelectedTicker
        {
            get { return this.selectedTicker; }
            set
            {
                if (this.selectedTicker != value)
                {
                    this.selectedTicker = value;
                    this.OnPropertyChanged("SelectedTicker");
                    this.GetQuotes(this.SelectedTicker.Ticker);
                }
            }
        }

        public int ZoomStartIndex
        {
            get { return this.zoomStartIndex; }
            set
            {
                if (this.zoomStartIndex != value)
                {
                    this.zoomStartIndex = value;
                    this.zoomedDataPoints.StartIndex = value;
                    this.OnPropertyChanged("ZoomStartIndex");
                }
            }
        }

        public int ZoomEndIndex
        {
            get { return this.zoomEndIndex; }
            set
            {
                if (this.zoomEndIndex != value)
                {
                    this.zoomEndIndex = value;
                    this.zoomedDataPoints.EndIndex = value;
                    this.OnPropertyChanged("ZoomEndIndex");
                }
            }
        }

        public double Minimum
        {
            get { return this.minimum; }
            private set
            {
                this.minimum = value;
                this.OnPropertyChanged("Minimum");
            }
        }

        public double Maximum
        {
            get { return this.maximum; }
            private set
            {
                this.maximum = value;
                this.OnPropertyChanged("Maximum");
            }
        }

        private void GetQuotes(string ticker)
        {
            if (this.getQuotesWorker != null)
            {
                this.getQuotesWorker.CancelAsync();
            }

            var quotes = Enumerable.Empty<Quote>();
            this.getQuotesWorker = new BackgroundWorker
            {
                WorkerSupportsCancellation = true
            };
            this.getQuotesWorker.DoWork += delegate
            {
                quotes = this.quoteService.GetHistoricalQuotes(ticker);
            };
            this.getQuotesWorker.RunWorkerCompleted += delegate
            {
                this.PopulateDataPoints(quotes);
            };
            this.getQuotesWorker.RunWorkerAsync();
        }

        private void PopulateDataPoints(IEnumerable<Quote> quotes)
        {
            var minimum = double.MaxValue;
            var maximum = double.MinValue;
            var dataPoints = new List<DataPoint>();

            foreach (var quote in quotes)
            {
                dataPoints.Add(new DataPoint(quote.Value));
                minimum = Math.Min(minimum, quote.Value);
                maximum = Math.Max(maximum, quote.Value);
            }

            this.Minimum = minimum;
            this.Maximum = maximum;
            this.AllDataPoints = new ListCollectionView(dataPoints);
            this.ZoomedDataPoints = new RangeCollectionView(dataPoints);
            this.ZoomStartIndex = 0;
            this.ZoomEndIndex = dataPoints.Count;
        }
    }
}