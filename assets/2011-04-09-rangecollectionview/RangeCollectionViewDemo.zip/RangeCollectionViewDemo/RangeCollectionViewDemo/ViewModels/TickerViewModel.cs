﻿namespace RangeCollectionViewDemo.ViewModels
{
    public sealed class TickerViewModel : ViewModel
    {
        private readonly string ticker;
        private readonly string display;

        public TickerViewModel(string ticker, string display)
        {
            this.ticker = ticker;
            this.display = display;
        }

        public string Ticker
        {
            get { return this.ticker; }
        }

        public string Display
        {
            get { return this.display; }
        }
    }
}