﻿using System;
using RangeCollectionViewDemo.Model;

namespace RangeCollectionViewDemo.ViewModels
{
    public sealed class QuoteViewModel : ViewModel
    {
        private readonly Quote quote;

        public QuoteViewModel(Quote quote)
        {
            this.quote = quote;
        }

        public DateTime Timestamp
        {
            get { return this.quote.Timestamp; }
        }

        public double Value
        {
            get { return this.quote.Value; }
        }
    }
}