﻿using System.Windows;
using RangeCollectionViewDemo.ViewModels;
using RangeCollectionViewDemo.Views;

namespace RangeCollectionViewDemo
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            // just cheating a bit here - wouldn't normally do it like this
            var view = new ChartView
            {
                DataContext = new ChartViewModel()
            };
            this.Content = view;
        }
    }
}