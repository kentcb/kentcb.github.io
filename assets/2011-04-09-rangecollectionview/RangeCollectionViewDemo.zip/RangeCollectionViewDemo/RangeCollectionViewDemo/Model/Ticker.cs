﻿namespace RangeCollectionViewDemo.Model
{
    public sealed class Ticker
    {
        private readonly string companyName;
        private readonly string symbol;

        public Ticker(string companyName, string symbol)
        {
            this.companyName = companyName;
            this.symbol = symbol;
        }

        public string CompanyName
        {
            get { return this.companyName; }
        }

        public string Symbol
        {
            get { return this.symbol; }
        }
    }
}