﻿using System;
using System.Diagnostics;

namespace RangeCollectionViewDemo.Model
{
    [DebuggerDisplay("Timestamp = {Timestamp}, Value = {value}")]
    public sealed class Quote
    {
        private readonly DateTime timestamp;
        private readonly double value;

        public Quote(DateTime timestamp, double value)
        {
            this.timestamp = timestamp;
            this.value = value;
        }

        public DateTime Timestamp
        {
            get { return this.timestamp; }
        }

        public double Value
        {
            get { return this.value; }
        }
    }
}