﻿using System.Collections.Generic;
using RangeCollectionViewDemo.Model;

namespace RangeCollectionViewDemo.Services
{
    public interface IQuoteService
    {
        IEnumerable<Ticker> Tickers
        {
            get;
        }

        IEnumerable<Quote> GetHistoricalQuotes(string ticker);
    }
}