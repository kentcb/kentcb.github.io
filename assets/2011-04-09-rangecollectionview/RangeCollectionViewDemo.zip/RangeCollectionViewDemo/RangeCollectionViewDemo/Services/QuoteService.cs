﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Net;
using Kent.Boogaart.KBCsv;
using RangeCollectionViewDemo.Model;

namespace RangeCollectionViewDemo.Services
{
    public sealed class QuoteService : IQuoteService
    {
        public IEnumerable<Ticker> Tickers
        {
            get
            {
                using (var stream = GetType().Assembly.GetManifestResourceStream("RangeCollectionViewDemo.Services.Tickers.csv"))
                using (var csvReader = new CsvReader(stream))
                {
                    csvReader.ReadHeaderRecord();

                    while (csvReader.HasMoreRecords)
                    {
                        var record = csvReader.ReadDataRecord();
                        yield return new Ticker(record["Name"], record["Symbol"]);
                    }
                }
            }
        }

        public IEnumerable<Quote> GetHistoricalQuotes(string ticker)
        {
            var quotes = new List<Quote>();

            try
            {
                using (var webClient = new WebClient())
                {
                    var url = string.Format("http://ichart.finance.yahoo.com/table.csv?s={0}", ticker);
                    var csv = webClient.DownloadString(url);

                    using (var csvReader = CsvReader.FromCsvString(csv))
                    {
                        csvReader.ReadHeaderRecord();

                        while (csvReader.HasMoreRecords)
                        {
                            var record = csvReader.ReadDataRecord();
                            var timestamp = DateTime.ParseExact(record["Date"], "yyyy-MM-dd", CultureInfo.InvariantCulture);
                            var value = double.Parse(record["Close"]);
                            quotes.Add(new Quote(timestamp, value));
                        }
                    }
                }
            }
            catch
            {
                // couldn't update subscription - would normally log this or something
            }

            return quotes;
        }
    }
}