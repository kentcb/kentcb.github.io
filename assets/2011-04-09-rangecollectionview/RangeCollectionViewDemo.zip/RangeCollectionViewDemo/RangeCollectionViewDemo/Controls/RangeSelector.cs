﻿using System;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Controls.Primitives;

namespace RangeCollectionViewDemo.Controls
{
    /// <summary>
    /// A control that allows a range to be selected.
    /// </summary>
    [TemplatePart(Name = StartAdjustmentThumbPartName, Type = typeof(Thumb))]
    [TemplatePart(Name = EndAdjustmentThumbPartName, Type = typeof(Thumb))]
    [TemplatePart(Name = SelectedRangePartName, Type = typeof(Thumb))]
    public class RangeSelector : Control
    {
        /// <summary>
        /// Identifies the <see cref="Minimum"/> property.
        /// </summary>
        public static readonly DependencyProperty MinimumProperty = DependencyProperty.Register(
            "Minimum",
            typeof(double),
            typeof(RangeSelector),
            new FrameworkPropertyMetadata(0d, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnMinimumChanged, OnCoerceMinimum));

        /// <summary>
        /// Identifies the <see cref="Maximum"/> property.
        /// </summary>
        public static readonly DependencyProperty MaximumProperty = DependencyProperty.Register(
            "Maximum",
            typeof(double),
            typeof(RangeSelector),
            new FrameworkPropertyMetadata(0d, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnMaximumChanged, OnCoerceMaximum));

        /// <summary>
        /// Identifies the <see cref="Start"/> property.
        /// </summary>
        public static readonly DependencyProperty StartProperty = DependencyProperty.Register(
            "Start",
            typeof(double),
            typeof(RangeSelector),
            new FrameworkPropertyMetadata(0d, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnStartChanged, OnCoerceStart));

        /// <summary>
        /// Identifies the <see cref="End"/> property.
        /// </summary>
        public static readonly DependencyProperty EndProperty = DependencyProperty.Register(
            "End",
            typeof(double),
            typeof(RangeSelector),
            new FrameworkPropertyMetadata(0d, FrameworkPropertyMetadataOptions.BindsTwoWayByDefault, OnEndChanged, OnCoerceEnd));

        private const string StartAdjustmentThumbPartName = "PART_StartAdjustmentThumb";
        private const string EndAdjustmentThumbPartName = "PART_EndAdjustmentThumb";
        private const string SelectedRangePartName = "PART_SelectedRange";
        private Thumb startAdjustmentThumb;
        private Thumb endAdjustmentThumb;
        private Thumb selectedRange;

        /// <summary>
        /// Initializes static members of the RangeSelector class.
        /// </summary>
        static RangeSelector()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(RangeSelector), new FrameworkPropertyMetadata(typeof(RangeSelector)));
        }

        /// <summary>
        /// Gets or sets the minimum value in the range.
        /// </summary>
        public double Minimum
        {
            get { return (double)this.GetValue(MinimumProperty); }
            set { this.SetValue(MinimumProperty, value); }
        }

        /// <summary>
        /// Gets or sets the maximum value in the range.
        /// </summary>
        public double Maximum
        {
            get { return (double)this.GetValue(MaximumProperty); }
            set { this.SetValue(MaximumProperty, value); }
        }

        /// <summary>
        /// Gets or sets the start value selected in the range.
        /// </summary>
        public double Start
        {
            get { return (double)this.GetValue(StartProperty); }
            set { this.SetValue(StartProperty, value); }
        }

        /// <summary>
        /// Gets or sets the end value selected in the range.
        /// </summary>
        public double End
        {
            get { return (double)this.GetValue(EndProperty); }
            set { this.SetValue(EndProperty, value); }
        }

        /// <summary>
        /// Called when the template for the control has been applied.
        /// </summary>
        public override void OnApplyTemplate()
        {
            base.OnApplyTemplate();

            this.startAdjustmentThumb = this.Template.FindName(StartAdjustmentThumbPartName, this) as Thumb;
            this.endAdjustmentThumb = this.Template.FindName(EndAdjustmentThumbPartName, this) as Thumb;
            this.selectedRange = this.Template.FindName(SelectedRangePartName, this) as Thumb;

            if (this.startAdjustmentThumb != null)
            {
                this.startAdjustmentThumb.DragDelta += this.OnStartAdjustmentThumbDragDelta;
            }

            if (this.endAdjustmentThumb != null)
            {
                this.endAdjustmentThumb.DragDelta += this.OnEndAdjustmentThumbDragDelta;
            }

            if (this.selectedRange != null)
            {
                this.selectedRange.DragDelta += this.OnSelectedRangeDragDelta;
            }
        }

        /// <summary>
        /// Raises the render size changed event.
        /// </summary>
        /// <param name="sizeInfo">
        /// The size information.
        /// </param>
        protected override void OnRenderSizeChanged(SizeChangedInfo sizeInfo)
        {
            base.OnRenderSizeChanged(sizeInfo);
            this.UpdateControls();
        }

        private static object OnCoerceMinimum(DependencyObject dependencyObject, object value)
        {
            var rangeSelector = (RangeSelector)dependencyObject;
            var effectiveValue = (double)value;
            effectiveValue = Math.Min(rangeSelector.Maximum, effectiveValue);

            return effectiveValue;
        }

        private static void OnMinimumChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            var rangeSelector = (RangeSelector)dependencyObject;
            rangeSelector.CoerceValue(MaximumProperty);
            rangeSelector.CoerceValue(StartProperty);
            rangeSelector.CoerceValue(EndProperty);
            rangeSelector.UpdateControls();
        }

        private static object OnCoerceMaximum(DependencyObject dependencyObject, object value)
        {
            var rangeSelector = (RangeSelector)dependencyObject;
            var effectiveValue = (double)value;
            effectiveValue = Math.Max(rangeSelector.Minimum, effectiveValue);

            return effectiveValue;
        }

        private static void OnMaximumChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            var rangeSelector = (RangeSelector)dependencyObject;
            rangeSelector.CoerceValue(MinimumProperty);
            rangeSelector.CoerceValue(StartProperty);
            rangeSelector.CoerceValue(EndProperty);
            rangeSelector.UpdateControls();
        }

        private static object OnCoerceStart(DependencyObject dependencyObject, object value)
        {
            var rangeSelector = (RangeSelector)dependencyObject;
            var effectiveValue = (double)value;
            effectiveValue = Math.Max(rangeSelector.Minimum, effectiveValue);
            effectiveValue = Math.Min(rangeSelector.Maximum, effectiveValue);
            effectiveValue = Math.Min(rangeSelector.End, effectiveValue);

            return effectiveValue;
        }

        private static void OnStartChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            var rangeSelector = (RangeSelector)dependencyObject;
            rangeSelector.CoerceValue(MinimumProperty);
            rangeSelector.CoerceValue(MaximumProperty);
            rangeSelector.CoerceValue(EndProperty);
            rangeSelector.UpdateControls();
        }

        private static object OnCoerceEnd(DependencyObject dependencyObject, object value)
        {
            var rangeSelector = (RangeSelector)dependencyObject;
            var effectiveValue = (double)value;
            effectiveValue = Math.Min(rangeSelector.Maximum, effectiveValue);
            effectiveValue = Math.Max(rangeSelector.Minimum, effectiveValue);
            effectiveValue = Math.Max(rangeSelector.Start, effectiveValue);

            return effectiveValue;
        }

        private static void OnEndChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            var rangeSelector = (RangeSelector)dependencyObject;
            rangeSelector.CoerceValue(MinimumProperty);
            rangeSelector.CoerceValue(MaximumProperty);
            rangeSelector.CoerceValue(StartProperty);
            rangeSelector.UpdateControls();
        }

        private void UpdateControls()
        {
            var totalSize = this.ActualWidth;
            var rangeSize = this.Maximum - this.Minimum;
            var ratio = totalSize / rangeSize;
            var rangeLeft = this.Start * ratio;
            var rangeRight = (this.End + 1) * ratio;
            rangeRight = Math.Max(rangeRight, rangeLeft);

            if (this.startAdjustmentThumb != null)
            {
                Canvas.SetLeft(this.startAdjustmentThumb, rangeLeft);
            }

            if (this.endAdjustmentThumb != null)
            {
                Canvas.SetLeft(this.endAdjustmentThumb, rangeRight);
            }

            if (this.selectedRange != null)
            {
                Canvas.SetLeft(this.selectedRange, rangeLeft);
                this.selectedRange.Width = rangeRight - rangeLeft;
            }
        }

        private void OnSelectedRangeDragDelta(object sender, DragDeltaEventArgs e)
        {
            this.MoveRange(e.HorizontalChange, true, true);
        }

        private void OnStartAdjustmentThumbDragDelta(object sender, DragDeltaEventArgs e)
        {
            this.MoveRange(e.HorizontalChange, true, false);
        }

        private void OnEndAdjustmentThumbDragDelta(object sender, DragDeltaEventArgs e)
        {
            this.MoveRange(e.HorizontalChange, false, true);
        }

        private void MoveRange(double moveBy, bool moveStart, bool moveEnd)
        {
            var pixelDiff = moveBy;
            var currentLeft = Canvas.GetLeft(this.startAdjustmentThumb);
            var currentRight = Canvas.GetLeft(this.endAdjustmentThumb);

            if (moveStart && ((currentLeft + pixelDiff) < 0))
            {
                // trying to drag too far left
                pixelDiff = currentLeft * -1;
            }

            if (moveEnd && ((currentRight + pixelDiff) > this.ActualWidth))
            {
                // trying to drag too far right
                pixelDiff = this.ActualWidth - currentRight;
            }

            var totalSize = this.ActualWidth;
            var ratioDiff = pixelDiff / totalSize;
            var rangeSize = this.Maximum - this.Minimum;
            var rangeDiff = rangeSize * ratioDiff;

            if (moveStart)
            {
                this.SetCurrentValue(StartProperty, Math.Max(this.Minimum, this.Start + rangeDiff));
            }

            if (moveEnd)
            {
                this.SetCurrentValue(EndProperty, Math.Min(this.Maximum, this.End + rangeDiff));
            }
        }
    }
}