﻿namespace RangeCollectionViewDemo.Controls
{
    public sealed class DataPoint
    {
        private readonly double value;

        public DataPoint(double value)
        {
            this.value = value;
        }

        public double Value
        {
            get { return this.value; }
        }
    }
}