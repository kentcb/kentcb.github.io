﻿using System.Collections;
using System.Collections.Specialized;
using System.Linq;
using System.Windows;
using System.Windows.Media;
using System.Windows.Shapes;

namespace RangeCollectionViewDemo.Controls
{
    public sealed class AreaSeries : Shape
    {
        public static readonly DependencyProperty MinimumProperty = DependencyProperty.Register(
            "Minimum",
            typeof(double),
            typeof(AreaSeries),
            new FrameworkPropertyMetadata(0d, FrameworkPropertyMetadataOptions.AffectsRender));

        public static readonly DependencyProperty MaximumProperty = DependencyProperty.Register(
            "Maximum",
            typeof(double),
            typeof(AreaSeries),
            new FrameworkPropertyMetadata(0d, FrameworkPropertyMetadataOptions.AffectsRender));

        public static readonly DependencyProperty DataPointsSourceProperty = DependencyProperty.Register(
            "DataPointsSource",
            typeof(IEnumerable),
            typeof(AreaSeries),
            new FrameworkPropertyMetadata(null, FrameworkPropertyMetadataOptions.AffectsRender, OnDataPointsChanged));

        public double Minimum
        {
            get { return (double)this.GetValue(MinimumProperty); }
            set { this.SetValue(MinimumProperty, value); }
        }

        public double Maximum
        {
            get { return (double)this.GetValue(MaximumProperty); }
            set { this.SetValue(MaximumProperty, value); }
        }

        public IEnumerable DataPointsSource
        {
            get { return this.GetValue(DataPointsSourceProperty) as IEnumerable; }
            set { this.SetValue(DataPointsSourceProperty, value); }
        }

        protected override Geometry DefiningGeometry
        {
            get
            {
                var streamGeometry = new StreamGeometry
                {
                    FillRule = FillRule.EvenOdd
                };

                using (var context = streamGeometry.Open())
                {
                    this.CreatePathData(context);
                }

                streamGeometry.Freeze();
                return streamGeometry;
            }
        }

        protected override Size MeasureOverride(Size constraint)
        {
            return Size.Empty;
        }

        private void CreatePathData(StreamGeometryContext context)
        {
            if (this.DataPointsSource == null)
            {
                return;
            }

            var dataPoints = this.DataPointsSource.Cast<DataPoint>().ToList();

            if (dataPoints.Count == 0)
            {
                return;
            }

            var minimum = this.Minimum;
            var maximum = this.Maximum;
            var width = this.ActualWidth;
            var height = this.ActualHeight;
            var xPerDataPoint = width / dataPoints.Count;
            var currentX = 0d;
            var points = (from dataPoint in dataPoints
                          let yRatio = 1d - (dataPoint.Value - minimum) / (maximum - minimum)
                          select new Point(currentX += xPerDataPoint, yRatio * height)).ToList();
            context.BeginFigure(new Point(0, height), true, true);
            context.LineTo(new Point(0, points[0].Y), true, true);
            context.PolyLineTo(points, true, true);
            context.LineTo(new Point(width, height), true, true);
        }

        private void OnDataPointsChanged(INotifyCollectionChanged oldDataPoints, INotifyCollectionChanged newDataPoints)
        {
            if (oldDataPoints != null)
            {
                newDataPoints.CollectionChanged -= OnDataPointsCollectionChanged;
            }

            if (newDataPoints != null)
            {
                newDataPoints.CollectionChanged += OnDataPointsCollectionChanged;
            }
        }

        private void OnDataPointsCollectionChanged(object sender, NotifyCollectionChangedEventArgs e)
        {
            this.InvalidateVisual();
        }

        private static void OnDataPointsChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            ((AreaSeries)dependencyObject).OnDataPointsChanged(e.OldValue as INotifyCollectionChanged, e.NewValue as INotifyCollectionChanged);
        }
    }
}