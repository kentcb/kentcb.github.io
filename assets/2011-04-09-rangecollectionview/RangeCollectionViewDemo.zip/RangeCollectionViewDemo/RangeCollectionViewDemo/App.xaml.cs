﻿using System.Windows;

namespace RangeCollectionViewDemo
{
    public partial class App : Application
    {
    }
}