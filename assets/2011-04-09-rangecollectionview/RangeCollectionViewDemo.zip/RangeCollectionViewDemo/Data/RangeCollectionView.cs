﻿using System;
using System.Collections;
using System.ComponentModel;
using System.Windows.Data;

namespace Data
{
    /// <summary>
    /// Implements a collection view that exposes a range of items in an underlying collection.
    /// </summary>
    public class RangeCollectionView : ListCollectionView
    {
        private int startIndex;
        private int endIndex;

        /// <summary>
        /// Initializes a new instance of the RangeCollectionView class.
        /// </summary>
        /// <param name="collection">
        /// The underlying collection.
        /// </param>
        public RangeCollectionView(IList collection)
            : base(collection)
        {
            if (this.InternalList.Count > 0)
            {
                this.endIndex = this.InternalList.Count - 1;
            }
        }

        /// <summary>
        /// Gets or sets the inclusive start index of the range exposed by this collection view.
        /// </summary>
        public int StartIndex
        {
            get
            {
                return this.startIndex;
            }

            set
            {
                if (this.startIndex != value)
                {
                    if (value < 0)
                    {
                        throw new ArgumentException("Start index cannot be less than zero.");
                    }

                    if (value > this.endIndex)
                    {
                        throw new ArgumentException("Start index cannot be greater than end index.");
                    }

                    this.startIndex = value;
                    this.RefreshOrDefer();

                    var item = this.GetItemAtInternalIndex(this.EffectiveStartIndex);
                    this.SetCurrent(item, item == null ? -1 : this.EffectiveStartIndex);

                    this.OnPropertyChanged(new PropertyChangedEventArgs("StartIndex"));
                }
            }
        }

        /// <summary>
        /// Gets or sets the inclusive end index of the range exposed by this collection view.
        /// </summary>
        public int EndIndex
        {
            get
            {
                return this.endIndex;
            }

            set
            {
                if (this.endIndex != value)
                {
                    if (value < 0)
                    {
                        throw new ArgumentException("End index cannot be less than zero.");
                    }

                    if (value < this.startIndex)
                    {
                        throw new ArgumentException("End index cannot be less than start index.");
                    }

                    this.endIndex = value;
                    this.RefreshOrDefer();

                    this.OnPropertyChanged(new PropertyChangedEventArgs("EndIndex"));
                }
            }
        }

        /// <summary>
        /// Gets the total number of items in the underlying collection regardless of the range exposed by this
        /// collection view.
        /// </summary>
        public int TotalItemCount
        {
            get { return this.InternalList.Count; }
        }

        /// <summary>
        /// Gets the number of items contained in this collection view.
        /// </summary>
        public override int Count
        {
            get { return this.EffectiveEndIndex - this.EffectiveStartIndex + 1; }
        }

        /// <summary>
        /// Gets the current position in this collection view.
        /// </summary>
        public override int CurrentPosition
        {
            get { return this.InternalIndexToRangeIndex(base.CurrentPosition); }
        }

        private int EffectiveStartIndex
        {
            get { return Math.Min(this.StartIndex, this.InternalList.Count); }
        }

        private int EffectiveEndIndex
        {
            get { return Math.Min(this.EndIndex, this.InternalList.Count - 1); }
        }

        private bool IsCurrentInView
        {
            get { return this.CurrentPosition >= 0 && this.CurrentPosition < this.Count; }
        }

        /// <summary>
        /// Determines whether this collection view contains the item specified.
        /// </summary>
        /// <param name="item">
        /// The item whose presence within the collection view is to be determined.
        /// </param>
        /// <returns>
        /// <see langword="true"/> if this collection view contains the item, otherwise <see langword="false"/>.
        /// </returns>
        public override bool Contains(object item)
        {
            return this.IndexOf(item) != -1;
        }

        /// <summary>
        /// Gets the index of the item within this collection view.
        /// </summary>
        /// <param name="item">
        /// The item whose index is to be determined.
        /// </param>
        /// <returns>
        /// The index of the item, or <c>-1</c> if the item is not in this collection view.
        /// </returns>
        public override int IndexOf(object item)
        {
            for (int i = this.EffectiveStartIndex; i <= this.EffectiveEndIndex; i++)
            {
                if (Equals(item, this.InternalList[i]))
                {
                    return i - this.EffectiveStartIndex;
                }
            }

            return -1;
        }

        /// <summary>
        /// Gets the item at the specified index.
        /// </summary>
        /// <param name="index">
        /// The index of the item.
        /// </param>
        /// <returns>
        /// The item at the specified index.
        /// </returns>
        public override object GetItemAt(int index)
        {
            if (index < 0)
            {
                throw new ArgumentOutOfRangeException("index", index, "index must be greater than or equal to zero.");
            }

            if (index >= this.Count)
            {
                throw new ArgumentOutOfRangeException("index", index, "index must be less than the number of items in the collection view.");
            }

            return base.GetItemAt(this.EffectiveStartIndex + index);
        }

        /// <summary>
        /// Moves the current item to a given position.
        /// </summary>
        /// <param name="position">
        /// The position to move to.
        /// </param>
        /// <returns>
        /// <see langword="true"/> if successful, otherwise <see langword="false"/>.
        /// </returns>
        public override bool MoveCurrentToPosition(int position)
        {
            base.MoveCurrentToPosition(this.RangeIndexToInternalIndex(position));

            // can't use return result from above call because it (incorrectly, I believe) uses InternalCount
            // rather than Count to determine whether the current item is in view. So we simply define our
            // own IsCurrentInView criteria and use that
            return this.IsCurrentInView;
        }

        /// <summary>
        /// Gets all items in this collection view.
        /// </summary>
        /// <returns>
        /// All items in this collection view.
        /// </returns>
        protected override IEnumerator GetEnumerator()
        {
            for (var i = this.EffectiveStartIndex; i <= this.EffectiveEndIndex; ++i)
            {
                yield return this.InternalList[i];
            }
        }

        private int InternalIndexToRangeIndex(int internalIndex)
        {
            if (internalIndex == this.InternalList.Count)
            {
                return this.Count;
            }

            if (internalIndex >= 0)
            {
                return internalIndex - this.EffectiveStartIndex;
            }

            return -1;
        }

        private int RangeIndexToInternalIndex(int rangeIndex)
        {
            if (rangeIndex == this.Count)
            {
                return this.InternalList.Count;
            }

            if (rangeIndex >= 0)
            {
                return rangeIndex + this.EffectiveStartIndex;
            }

            return -1;
        }

        private object GetItemAtInternalIndex(int index)
        {
            if (index < 0 || index >= this.InternalList.Count)
            {
                return null;
            }

            return this.InternalList[index];
        }
    }
}