﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.ComponentModel;
using System.Windows.Data;
using NUnit.Framework;

namespace Data.Tests
{
    [TestFixture]
    public class RangeCollectionViewFixture
    {
        private IList collection;
        private RangeCollectionView collectionView;

        [SetUp]
        public void Setup()
        {
            this.collection = new List<string> { "one", "two", "three", "four", "five", "six", "seven", "eight", "nine", "ten" };
            this.collectionView = new RangeCollectionView(this.collection);
        }

        [Test]
        public void ConstructorShouldThrowIfNullCollection()
        {
            Assert.Throws<ArgumentNullException>(() => new RangeCollectionView(null));
        }

        [Test]
        public void StartIndexShouldDefaultToZero()
        {
            Assert.AreEqual(0, this.collectionView.StartIndex);
        }

        [Test]
        public void StartIndexCannotBeLessThanZero()
        {
            var ex = Assert.Throws<ArgumentException>(() => this.collectionView.StartIndex = -1);
            Assert.AreEqual("Start index cannot be less than zero.", ex.Message);
        }

        [Test]
        public void StartIndexCannotBeGreaterThanEndIndex()
        {
            var ex = Assert.Throws<ArgumentException>(() => this.collectionView.StartIndex = 100);
            Assert.AreEqual("Start index cannot be greater than end index.", ex.Message);
        }

        [Test]
        public void StartIndexUpdatesCurrentItem()
        {
            Assert.AreEqual("one", this.collectionView.CurrentItem);

            this.collectionView.StartIndex = 4;
            Assert.AreEqual("five", this.collectionView.CurrentItem);

            this.collectionView.StartIndex = 2;
            Assert.AreEqual("three", this.collectionView.CurrentItem);
        }

        [Test]
        public void StartIndexRaisesPropertyChangedWhenRelevant()
        {
            var changed = false;

            (this.collectionView as INotifyPropertyChanged).PropertyChanged += delegate(object sender, PropertyChangedEventArgs e)
            {
                if (string.Equals("StartIndex", e.PropertyName, StringComparison.Ordinal))
                {
                    changed = true;
                }
            };

            this.collectionView.StartIndex = 4;
            Assert.True(changed);

            changed = false;
            this.collectionView.StartIndex = 4;
            Assert.False(changed);

            this.collectionView.StartIndex = 3;
            Assert.True(changed);
        }

        [Test]
        public void EndIndexShouldDefaultToZero()
        {
            Assert.AreEqual(9, this.collectionView.EndIndex);
        }

        [Test]
        public void EndIndexCannotBeLessThanZero()
        {
            var ex = Assert.Throws<ArgumentException>(() => this.collectionView.EndIndex = -1);
            Assert.AreEqual("End index cannot be less than zero.", ex.Message);
        }

        [Test]
        public void EndIndexCannotBeLessThanStartIndex()
        {
            this.collectionView.StartIndex = 3;
            var ex = Assert.Throws<ArgumentException>(() => this.collectionView.EndIndex = 2);
            Assert.AreEqual("End index cannot be less than start index.", ex.Message);
        }

        [Test]
        public void EndIndexRaisesPropertyChangedWhenRelevant()
        {
            var changed = false;

            (this.collectionView as INotifyPropertyChanged).PropertyChanged += delegate(object sender, PropertyChangedEventArgs e)
            {
                if (string.Equals("EndIndex", e.PropertyName, StringComparison.Ordinal))
                {
                    changed = true;
                }
            };

            this.collectionView.EndIndex = 4;
            Assert.True(changed);

            changed = false;
            this.collectionView.EndIndex = 4;
            Assert.False(changed);

            this.collectionView.EndIndex = 3;
            Assert.True(changed);
        }

        [Test]
        public void RefreshCanBeDeferredForStartAndEndIndexChanges()
        {
            var changed = false;
            (this.collectionView as INotifyCollectionChanged).CollectionChanged += delegate
            {
                changed = true;
            };

            using (this.collectionView.DeferRefresh())
            {
                this.collectionView.StartIndex = 3;
                Assert.False(changed);
                this.collectionView.EndIndex = 7;
                Assert.False(changed);
                this.collectionView.EndIndex = 6;
                Assert.False(changed);
            }

            Assert.True(changed);
        }

        [Test]
        public void CountReturnsSizeOfRangeIfRangeIsWithinBounds()
        {
            Assert.AreEqual(10, this.collectionView.Count);

            this.collectionView.StartIndex = 1;
            Assert.AreEqual(9, this.collectionView.Count);

            this.collectionView.EndIndex = 8;
            Assert.AreEqual(8, this.collectionView.Count);

            this.collectionView.StartIndex = 4;
            this.collectionView.EndIndex = 5;
            Assert.AreEqual(2, this.collectionView.Count);

            this.collectionView.EndIndex = 4;
            Assert.AreEqual(1, this.collectionView.Count);

            this.collectionView.EndIndex = 9;
            this.collectionView.StartIndex = 9;
            Assert.AreEqual(1, this.collectionView.Count);
        }

        [Test]
        public void CountReturnsSizeOfEffectiveRangeIfRangeIsOutsideBounds()
        {
            this.collectionView.EndIndex = 1000;
            Assert.AreEqual(10, this.collectionView.Count);

            this.collectionView.StartIndex = 5;
            Assert.AreEqual(5, this.collectionView.Count);

            this.collectionView.StartIndex = 20;
            Assert.AreEqual(0, this.collectionView.Count);

            this.collectionView.StartIndex = 9;
            this.collectionView.EndIndex = 10;
            Assert.AreEqual(1, this.collectionView.Count);
        }

        [Test]
        public void GetEnumeratorOnlyReturnsItemsWithinRange()
        {
            this.collectionView.StartIndex = 2;
            this.collectionView.EndIndex = 4;

            var enumerator = (this.collectionView as IEnumerable).GetEnumerator();
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("three", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("four", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("five", enumerator.Current);
            Assert.False(enumerator.MoveNext());
        }

        [Test]
        public void ContainsOnlyReturnsTrueForItemsWithinRange()
        {
            this.collectionView.StartIndex = 2;
            this.collectionView.EndIndex = 4;

            Assert.False(this.collectionView.Contains(null));
            Assert.False(this.collectionView.Contains("one"));
            Assert.False(this.collectionView.Contains("two"));
            Assert.True(this.collectionView.Contains("three"));
            Assert.True(this.collectionView.Contains("four"));
            Assert.True(this.collectionView.Contains("five"));
            Assert.False(this.collectionView.Contains("six"));
        }

        [Test]
        public void IndexOfOnlyReturnsIndexesForItemsWithinRange()
        {
            this.collectionView.StartIndex = 2;
            this.collectionView.EndIndex = 4;

            Assert.AreEqual(-1, this.collectionView.IndexOf(null));
            Assert.AreEqual(-1, this.collectionView.IndexOf("one"));
            Assert.AreEqual(-1, this.collectionView.IndexOf("two"));
            Assert.AreEqual(0, this.collectionView.IndexOf("three"));
            Assert.AreEqual(1, this.collectionView.IndexOf("four"));
            Assert.AreEqual(2, this.collectionView.IndexOf("five"));
            Assert.AreEqual(-1, this.collectionView.IndexOf("six"));
        }

        [Test]
        public void GetItemAtThrowsIfIndexIsLessThanZero()
        {
            Assert.Throws<ArgumentOutOfRangeException>(() => this.collectionView.GetItemAt(-1));
            Assert.Throws<ArgumentOutOfRangeException>(() => this.collectionView.GetItemAt(-20));
            Assert.Throws<ArgumentOutOfRangeException>(() => this.collectionView.GetItemAt(int.MinValue));
        }

        [Test]
        public void GetItemAtThrowsIfIndexIsGreaterThanCount()
        {
            this.collectionView.StartIndex = 2;
            this.collectionView.EndIndex = 4;

            Assert.Throws<ArgumentOutOfRangeException>(() => this.collectionView.GetItemAt(4));
            Assert.Throws<ArgumentOutOfRangeException>(() => this.collectionView.GetItemAt(10));
            Assert.Throws<ArgumentOutOfRangeException>(() => this.collectionView.GetItemAt(int.MaxValue));
        }

        [Test]
        public void GetItemAtReturnsItemRelativeToStartIndex()
        {
            this.collectionView.StartIndex = 2;
            this.collectionView.EndIndex = 4;

            Assert.AreEqual("three", this.collectionView.GetItemAt(0));
            Assert.AreEqual("four", this.collectionView.GetItemAt(1));
            Assert.AreEqual("five", this.collectionView.GetItemAt(2));
        }

        [Test]
        public void GetItemAtSupportsSorting()
        {
            this.collectionView.StartIndex = 2;
            this.collectionView.EndIndex = 4;

            // sort by text, descending
            this.collectionView.SortDescriptions.Add(new SortDescription(".", ListSortDirection.Descending));

            Assert.AreEqual("ten", this.collectionView.GetItemAt(0));
            Assert.AreEqual("six", this.collectionView.GetItemAt(1));
            Assert.AreEqual("seven", this.collectionView.GetItemAt(2));
        }

        [Test]
        public void FilteringIsSupported()
        {
            this.collectionView.Filter = delegate(object o)
            {
                return ((string)o).StartsWith("t", StringComparison.OrdinalIgnoreCase);
            };

            Assert.AreEqual(3, this.collectionView.Count);
            var enumerator = (this.collectionView as IEnumerable).GetEnumerator();
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("two", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("three", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("ten", enumerator.Current);
            Assert.False(enumerator.MoveNext());
        }

        [Test]
        public void SortedIsSupported()
        {
            // sort by text, ascending
            this.collectionView.SortDescriptions.Add(new SortDescription(".", ListSortDirection.Ascending));

            var enumerator = (this.collectionView as IEnumerable).GetEnumerator();
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("eight", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("five", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("four", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("nine", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("one", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("seven", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("six", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("ten", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("three", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("two", enumerator.Current);
            Assert.False(enumerator.MoveNext());

            // sort by length, ascending and then text, descending
            using (this.collectionView.DeferRefresh())
            {
                this.collectionView.SortDescriptions.Clear();
                this.collectionView.SortDescriptions.Add(new SortDescription("Length", ListSortDirection.Ascending));
                this.collectionView.SortDescriptions.Add(new SortDescription(".", ListSortDirection.Descending));
            }

            enumerator = (this.collectionView as IEnumerable).GetEnumerator();
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("two", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("ten", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("six", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("one", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("nine", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("four", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("five", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("three", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("seven", enumerator.Current);
            Assert.True(enumerator.MoveNext());
            Assert.AreEqual("eight", enumerator.Current);
            Assert.False(enumerator.MoveNext());
        }

        [Test]
        public void GroupingIsSupported()
        {
            this.collectionView.GroupDescriptions.Add(new PropertyGroupDescription("Length"));

            Assert.AreEqual(3, this.collectionView.Groups.Count);

            // group containing words of length 3
            Assert.AreEqual(3, ((CollectionViewGroup)this.collectionView.Groups[0]).Name);
            Assert.AreEqual(4, ((CollectionViewGroup)this.collectionView.Groups[0]).ItemCount);

            // group containing words of length 5
            Assert.AreEqual(5, ((CollectionViewGroup)this.collectionView.Groups[1]).Name);
            Assert.AreEqual(3, ((CollectionViewGroup)this.collectionView.Groups[1]).ItemCount);

            // group containing words of length 4
            Assert.AreEqual(4, ((CollectionViewGroup)this.collectionView.Groups[2]).Name);
            Assert.AreEqual(3, ((CollectionViewGroup)this.collectionView.Groups[2]).ItemCount);
        }

        [Test]
        public void SelectionIsSupported()
        {
            this.collectionView.StartIndex = 3;
            this.collectionView.EndIndex = 5;

            Assert.AreEqual("four", this.collectionView.CurrentItem);

            Assert.True(this.collectionView.MoveCurrentTo("five"));
            Assert.NotNull(this.collectionView.CurrentItem);
            Assert.AreEqual("five", this.collectionView.CurrentItem);

            Assert.False(this.collectionView.MoveCurrentTo("one"));
            Assert.Null(this.collectionView.CurrentItem);

            Assert.True(this.collectionView.MoveCurrentToPosition(0));
            Assert.AreEqual("four", this.collectionView.CurrentItem);

            Assert.True(this.collectionView.MoveCurrentToNext());
            Assert.AreEqual("five", this.collectionView.CurrentItem);

            Assert.True(this.collectionView.MoveCurrentToNext());
            Assert.AreEqual("six", this.collectionView.CurrentItem);

            Assert.False(this.collectionView.MoveCurrentToNext());
            Assert.Null(this.collectionView.CurrentItem);

            Assert.True(this.collectionView.MoveCurrentToPrevious());
            Assert.AreEqual("six", this.collectionView.CurrentItem);

            Assert.True(this.collectionView.MoveCurrentToPrevious());
            Assert.AreEqual("five", this.collectionView.CurrentItem);

            Assert.True(this.collectionView.MoveCurrentToPrevious());
            Assert.AreEqual("four", this.collectionView.CurrentItem);

            Assert.False(this.collectionView.MoveCurrentToPrevious());
            Assert.Null(this.collectionView.CurrentItem);

            Assert.True(this.collectionView.MoveCurrentToLast());
            Assert.AreEqual("six", this.collectionView.CurrentItem);

            Assert.True(this.collectionView.MoveCurrentToFirst());
            Assert.AreEqual("four", this.collectionView.CurrentItem);
        }

        [Test]
        public void ListCollectionViewTest()
        {
            var listCollectionView = new ListCollectionView(this.collection);
            listCollectionView.MoveCurrentToPosition(10);
            Assert.Null(listCollectionView.CurrentItem);
            Assert.True(listCollectionView.IsCurrentAfterLast);

            listCollectionView.MoveCurrentTo("nine");
            Assert.True(listCollectionView.MoveCurrentToNext());
            Assert.False(listCollectionView.MoveCurrentToNext());
        }
    }
}