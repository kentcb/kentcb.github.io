﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace TieredExperience
{
    /// <summary>
    /// Implements a <see cref="VisualStateManager"/> that can be used to provide a different experience based on tiers.
    /// </summary>
    /// <remarks>
    /// <para>
    /// The <c>TieredVisualStateManager</c> can be used to break a user experience into tiers and apply an appropriate
    /// experience based on the <see cref="ActiveTier"/>. Visual state and transition information for specific tiers
    /// must be added to the <c>TieredVisualStateGroups</c> attached collection. Visual state and transition
    /// information not specific to any particular tier should be added to the <c>VisualStateGroups</c> attached
    /// collection.
    /// </para>
    /// <para>
    /// When determining the visual state and transition information to apply for a given state, the
    /// <c>TieredVisualStateManager</c> uses the <see cref="ActiveTier"/> and <see cref="AggregateTiers"/> properties.
    /// The former tells it the maximum tier that will be considered when collating visual state and transitions, whilst
    /// the latter tells it whether it should automatically aggregate visual states and transitions from lower tiers
    /// than the active tier.
    /// </para>
    /// </remarks>
    public class TieredVisualStateManager : VisualStateManager
    {
        /// <summary>
        /// Identifies the <see cref="AggregateTiers"/> property.
        /// </summary>
        public static readonly DependencyProperty AggregateTiersProperty = DependencyProperty.Register(
            "AggregateTiers",
            typeof(bool),
            typeof(TieredVisualStateManager),
            new FrameworkPropertyMetadata(true));

        /// <summary>
        /// Identifies the <c>TieredVisualStateGroups</c> attached property.
        /// </summary>
        public static readonly DependencyProperty TieredVisualStateGroupsProperty = DependencyProperty.RegisterAttached(
            "TieredVisualStateGroups",
            typeof(TieredVisualStateGroupCollection),
            typeof(TieredVisualStateManager),
            new FrameworkPropertyMetadata(OnTieredVisualStateGroupsChanged));

        private static readonly IDictionary<FrameworkElement, StateGroupsRootInfo> stateGroupsRootMap = new Dictionary<FrameworkElement, StateGroupsRootInfo>();
        private static Tier activeTier;
        private static bool updateLatch;

        /// <summary>
        /// Initializes static members of the TieredVisualStateManager class.
        /// </summary>
        [SuppressMessage("Microsoft.Performance", "CA1810", Justification = "Cannot do this inline.")]
        static TieredVisualStateManager()
        {
            // when the current user experience scale changes, we need to re-apply any state changes to ensure the most appropriate VisualState
            // is chosen
            ActiveTierChanged += delegate
            {
                InvalidateStates();
            };
        }

        /// <summary>
        /// Occurs whenever the <see cref="ActiveTier"/> changes.
        /// </summary>
        public static event EventHandler<EventArgs> ActiveTierChanged;

        /// <summary>
        /// An extension of <see cref="Tier"/> that adds a <see cref="TierWithNone.None"/> member.
        /// </summary>
        private enum TierWithNone
        {
            /// <summary>
            /// Specifies a lack of tier.
            /// </summary>
            None = Tier.Low - 1,

            /// <summary>
            /// The low tier.
            /// </summary>
            Low = Tier.Low,

            /// <summary>
            /// The medium tier.
            /// </summary>
            Medium = Tier.Medium,

            /// <summary>
            /// The high tier.
            /// </summary>
            High = Tier.High,
        }

        /// <summary>
        /// Gets or sets the active tier.
        /// </summary>
        /// <remarks>
        /// Generally speaking, this property should rarely be changed. Typically, it would be set once on application
        /// startup based on the performance of the client machine. It may also be exposed to users via application
        /// options.
        /// </remarks>
        public static Tier ActiveTier
        {
            get
            {
                return activeTier;
            }

            set
            {
                if (activeTier != value)
                {
                    activeTier = value;
                    OnActiveTierChanged();
                }
            }
        }

        /// <summary>
        /// Gets or sets a value indicating whether tiers should be aggregated when collating visual state and transition
        /// information.
        /// </summary>
        /// <remarks>
        /// <para>
        /// If this property is set to <see langword="true"/> (the default), visual states and transitions from lower
        /// tiers than the active tier will be aggregated together. For example, if the active tier is
        /// <see cref="Tier.Medium"/>, any visual states and transitions defined in <see cref="Tier.Low"/> would also be
        /// applied. However, any visual states and transitions in <see cref="Tier.High"/> would not.
        /// </para>
        /// <para>
        /// If this property is set to <see langword="false"/>, only those visual states and transitions assigned directly
        /// to the active tier will be applied.
        /// </para>
        /// </remarks>
        public bool AggregateTiers
        {
            get { return (bool)this.GetValue(AggregateTiersProperty); }
            set { this.SetValue(AggregateTiersProperty, value); }
        }

        /// <summary>
        /// Gets the tiered visual state group collection for a given <see cref="FrameworkElement"/>.
        /// </summary>
        /// <param name="frameworkElement">
        /// The framework element.
        /// </param>
        /// <returns>
        /// A <see cref="TieredVisualStateGroupCollection"/>, or <see langword="null"/>.
        /// </returns>
        [SuppressMessage("Microsoft.Design", "CA1011", Justification = "VisualStateManager visual state group roots must be framework elements.")]
        public static TieredVisualStateGroupCollection GetTieredVisualStateGroups(FrameworkElement frameworkElement)
        {
            return frameworkElement.GetValue(TieredVisualStateGroupsProperty) as TieredVisualStateGroupCollection;
        }

        /// <summary>
        /// Sets the tiered visual state group collection for a given <see cref="FrameworkElement"/>.
        /// </summary>
        /// <param name="frameworkElement">
        /// The framework element.
        /// </param>
        /// <param name="tieredVisualStateGroups">
        /// The <see cref="TieredVisualStateGroupCollection"/>.
        /// </param>
        [SuppressMessage("Microsoft.Design", "CA1011", Justification = "VisualStateManager visual state group roots must be framework elements.")]
        public static void SetTieredVisualStateGroups(FrameworkElement frameworkElement, TieredVisualStateGroupCollection tieredVisualStateGroups)
        {
            frameworkElement.SetValue(TieredVisualStateGroupsProperty, tieredVisualStateGroups);
        }

        /// <summary>
        /// Performs the specified state transition.
        /// </summary>
        /// <param name="control">
        /// The control whose state is being changed.
        /// </param>
        /// <param name="templateRoot">
        /// The control containing the state groups.
        /// </param>
        /// <param name="stateName">
        /// The target state name.
        /// </param>
        /// <param name="group">
        /// The visual state group.
        /// </param>
        /// <param name="state">
        /// The visual state.
        /// </param>
        /// <param name="useTransitions">
        /// <see langword="true"/> if transitions should be applied, otherwise <see langword="false"/>.
        /// </param>
        /// <returns>
        /// <see langword="true"/> if the state change was successful, otherwise <see langword="false"/>.
        /// </returns>
        protected override bool GoToStateCore(FrameworkElement control, FrameworkElement templateRoot, string stateName, VisualStateGroup group, VisualState state, bool useTransitions)
        {
            var stateGroupsRootInfo = this.EnsureStateGroupsRoot(control, templateRoot);
            var currentTier = ActiveTier;

            if (!stateGroupsRootInfo.VisualStateToVisualStateGroupMap.TryGetValue(stateName, out group))
            {
                return false;
            }

            this.EnsureVisualStateGroupPopulatedForTier(templateRoot, (TierWithNone)currentTier);

            state = group.States.Cast<VisualState>().FirstOrDefault(x => x.Name == stateName);

            if (group == null || state == null)
            {
                return false;
            }

            if (!updateLatch)
            {
                stateGroupsRootInfo.CurrentStates[group.Name] = state.Name;
            }

            return base.GoToStateCore(control, templateRoot, stateName, group, state, useTransitions);
        }

        private static void OnActiveTierChanged()
        {
            var handler = ActiveTierChanged;

            if (handler != null)
            {
                handler(null, EventArgs.Empty);
            }
        }

        private static void OnTieredVisualStateGroupsChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            var frameworkElement = (FrameworkElement)dependencyObject;
            var visualStateGroups = GetVisualStateGroups(frameworkElement);
            Debug.Assert(visualStateGroups != null, "Expecting visual state groups to never be null.");

            // HACK: without at least one VisualStateGroup, the VisualStateManager refuses to even call GoToStateCore
            // on our custom visual state manager
            if (visualStateGroups.Count == 0)
            {
                visualStateGroups.Add(new VisualStateGroup());
            }
        }

        private static void PopulateStateGroupsRootInfoForStateGroupsRoot(FrameworkElement stateGroupsRoot, StateGroupsRootInfo stateGroupsRootInfo)
        {
            var tieredVisualStateGroups = GetTieredVisualStateGroups(stateGroupsRoot);
            var visualStateGroups = GetVisualStateGroups(stateGroupsRoot).Cast<VisualStateGroup>();

            foreach (var visualStateGroup in visualStateGroups.Concat(tieredVisualStateGroups.Cast<VisualStateGroup>()))
            {
                var tieredVisualStateGroup = visualStateGroup as TieredVisualStateGroup;
                var name = visualStateGroup.Name;
                var tier = TierWithNone.None;

                if (tieredVisualStateGroup != null)
                {
                    name = tieredVisualStateGroup.Name;
                    tier = (TierWithNone)tieredVisualStateGroup.Tier;
                }

                var existingVisualStateGroup = stateGroupsRootInfo.VisualStateGroups.FirstOrDefault(x => x.Name == name);
                var visualStateGroupToUse = existingVisualStateGroup ?? new VisualStateGroup { Name = name };

                if (!stateGroupsRootInfo.VisualStatesByTier.ContainsKey(tier))
                {
                    stateGroupsRootInfo.VisualStatesByTier[tier] = new List<VisualState>();
                }

                foreach (VisualState visualState in visualStateGroup.States)
                {
                    stateGroupsRootInfo.VisualStatesByTier[tier].Add(visualState);
                    stateGroupsRootInfo.VisualStateToVisualStateGroupMap[visualState.Name] = visualStateGroupToUse;
                }

                if (!stateGroupsRootInfo.VisualTransitionsByTier.ContainsKey(tier))
                {
                    stateGroupsRootInfo.VisualTransitionsByTier[tier] = new List<VisualTransition>();
                }

                foreach (VisualTransition visualTransition in visualStateGroup.Transitions)
                {
                    stateGroupsRootInfo.VisualTransitionsByTier[tier].Add(visualTransition);
                    stateGroupsRootInfo.VisualTransitionToVisualStateGroupMap[StateGroupsRootInfo.GetKeyForVisualTransition(visualTransition)] = visualStateGroupToUse;
                }

                if (existingVisualStateGroup != null)
                {
                    continue;
                }

                stateGroupsRootInfo.VisualStateGroups.Add(visualStateGroupToUse);
            }
        }

        private static void InvalidateStates()
        {
            updateLatch = true;

            try
            {
                foreach (var kvp in stateGroupsRootMap)
                {
                    var stateGroupsRootInfo = kvp.Value;
                    stateGroupsRootInfo.RequiresPopulation = true;
                    var control = stateGroupsRootInfo.Control;

                    foreach (var currentState in stateGroupsRootInfo.CurrentStates.Values)
                    {
                        GoToState(control, currentState, false);
                    }
                }
            }
            finally
            {
                updateLatch = false;
            }
        }

        private StateGroupsRootInfo EnsureStateGroupsRoot(FrameworkElement control, FrameworkElement stateGroupsRoot)
        {
            // make sure the control has an entry in stateGroupRootMap
            StateGroupsRootInfo stateGroupsRootInfo;

            if (!stateGroupsRootMap.TryGetValue(stateGroupsRoot, out stateGroupsRootInfo))
            {
                // make sure we tidy up if the control is unloaded
                stateGroupsRoot.Unloaded += this.OnStateGroupsRootUnloaded;

                stateGroupsRootInfo = new StateGroupsRootInfo(control);
                stateGroupsRootMap[stateGroupsRoot] = stateGroupsRootInfo;

                PopulateStateGroupsRootInfoForStateGroupsRoot(stateGroupsRoot, stateGroupsRootInfo);
            }

            return stateGroupsRootInfo;
        }

        private void EnsureVisualStateGroupPopulatedForTier(FrameworkElement stateGroupsRoot, TierWithNone tier)
        {
            var stateGroupsRootInfo = stateGroupsRootMap[stateGroupsRoot];

            if (!stateGroupsRootInfo.RequiresPopulation)
            {
                return;
            }

            foreach (var visualStateGroup in stateGroupsRootInfo.VisualStateGroups)
            {
                if (visualStateGroup.Name == null)
                {
                    continue;
                }

                visualStateGroup.States.Clear();
                visualStateGroup.Transitions.Clear();

                foreach (var visualState in stateGroupsRootInfo.GetAllVisualStates(visualStateGroup.Name, tier, this.AggregateTiers))
                {
                    visualStateGroup.States.Add(visualState);
                }

                foreach (var visualTransition in stateGroupsRootInfo.GetAllVisualTransitions(visualStateGroup.Name, tier, this.AggregateTiers))
                {
                    visualStateGroup.Transitions.Add(visualTransition);
                }
            }

            stateGroupsRootInfo.RequiresPopulation = false;
        }

        private void OnStateGroupsRootUnloaded(object sender, RoutedEventArgs e)
        {
            var stateGroupsRoot = (FrameworkElement)sender;
            stateGroupsRoot.Unloaded -= this.OnStateGroupsRootUnloaded;
            stateGroupsRootMap.Remove(stateGroupsRoot);
        }

        /// <summary>
        /// Contains information about a state groups root object.
        /// </summary>
        private sealed class StateGroupsRootInfo
        {
            private readonly FrameworkElement control;
            private readonly ICollection<VisualStateGroup> visualStateGroups;
            private readonly IDictionary<TierWithNone, IList<VisualState>> visualStatesByTier;
            private readonly IDictionary<TierWithNone, IList<VisualTransition>> visualTransitionsByTier;
            private readonly IDictionary<string, VisualStateGroup> visualStateToVisualStateGroupMap;
            private readonly IDictionary<string, VisualStateGroup> visualTransitionToVisualStateGroupMap;
            private readonly IDictionary<string, string> currentStates;
            private bool requiresPopulation;

            /// <summary>
            /// Initializes a new instance of the StateGroupsRootInfo class.
            /// </summary>
            /// <param name="control">
            /// The control that contains the state groups root.
            /// </param>
            public StateGroupsRootInfo(FrameworkElement control)
            {
                Debug.Assert(control != null, "Expecting control to be non-null.");

                this.control = control;
                this.visualStateGroups = new List<VisualStateGroup>();
                this.visualStatesByTier = new Dictionary<TierWithNone, IList<VisualState>>();
                this.visualTransitionsByTier = new Dictionary<TierWithNone, IList<VisualTransition>>();
                this.visualStateToVisualStateGroupMap = new Dictionary<string, VisualStateGroup>();
                this.visualTransitionToVisualStateGroupMap = new Dictionary<string, VisualStateGroup>();
                this.currentStates = new Dictionary<string, string>();
                this.requiresPopulation = true;
            }

            /// <summary>
            /// Gets the control that contains the state groups root.
            /// </summary>
            public FrameworkElement Control
            {
                get { return this.control; }
            }

            /// <summary>
            /// Gets all visual state groups in the state group, be they tiered or non-tiered.
            /// </summary>
            public ICollection<VisualStateGroup> VisualStateGroups
            {
                get { return this.visualStateGroups; }
            }

            /// <summary>
            /// Gets a dictionary that maps a tier to a list of visual states defined directly in that tier.
            /// </summary>
            public IDictionary<TierWithNone, IList<VisualState>> VisualStatesByTier
            {
                get { return this.visualStatesByTier; }
            }

            /// <summary>
            /// Gets a dictionary that maps a tier to a list of visual transitions defined directly in that tier.
            /// </summary>
            public IDictionary<TierWithNone, IList<VisualTransition>> VisualTransitionsByTier
            {
                get { return this.visualTransitionsByTier; }
            }

            /// <summary>
            /// Gets a dictionary that maps visual state names to their owning visual state group instance.
            /// </summary>
            public IDictionary<string, VisualStateGroup> VisualStateToVisualStateGroupMap
            {
                get { return this.visualStateToVisualStateGroupMap; }
            }

            /// <summary>
            /// Gets a dictionary that maps visual transition keys to their owning visual state group instance.
            /// </summary>
            public IDictionary<string, VisualStateGroup> VisualTransitionToVisualStateGroupMap
            {
                get { return this.visualTransitionToVisualStateGroupMap; }
            }

            /// <summary>
            /// Gets a dictionary that maps visual state group names to the current state for that group.
            /// </summary>
            public IDictionary<string, string> CurrentStates
            {
                get { return this.currentStates; }
            }

            /// <summary>
            /// Gets or sets a value indicating whether the visual state group requires population.
            /// </summary>
            public bool RequiresPopulation
            {
                get { return this.requiresPopulation; }
                set { this.requiresPopulation = value; }
            }

            /// <summary>
            /// Gets a key used to store visual transitions in a dictionary.
            /// </summary>
            /// <param name="visualTransition">
            /// The visual transition.
            /// </param>
            /// <returns>
            /// The key for the visual transition.
            /// </returns>
            public static string GetKeyForVisualTransition(VisualTransition visualTransition)
            {
                Debug.Assert(visualTransition != null, "Expecting visual transition to be non-null.");
                return visualTransition.From + " -> " + visualTransition.To;
            }

            /// <summary>
            /// Gets all visual states in a given visual state group and tier, optionally aggregating lower tiers.
            /// </summary>
            /// <param name="visualStateGroupName">
            /// The name of the visual state group.
            /// </param>
            /// <param name="tier">
            /// The maximum tier in which visual states may be returned.
            /// </param>
            /// <param name="aggregate">
            /// <see langword="true"/> to aggregate lower tiers.
            /// </param>
            /// <returns>
            /// All relevant visual states.
            /// </returns>
            public IEnumerable<VisualState> GetAllVisualStates(string visualStateGroupName, TierWithNone tier, bool aggregate)
            {
                if (!aggregate)
                {
                    // if we're not aggregating just return all visual states assigned to the tier, then all assigned to no particular tier
                    var visualStatesInTier = this.SafeGetAllVisualStatesForGroupAndTier(visualStateGroupName, tier);
                    var visualStatesInNoTier = this.SafeGetAllVisualStatesForGroupAndTier(visualStateGroupName, TierWithNone.None);

                    return visualStatesInTier.Concat(visualStatesInNoTier);
                }

                // if we're aggregating, we need to combine visual states in all tiers at or below the specified tier, in order from lowest to highest
                var aggregatedVisualStates = new Dictionary<string, VisualState>();

                for (var tierToAggregate = TierWithNone.None; tierToAggregate <= tier; ++tierToAggregate)
                {
                    foreach (var visualState in this.SafeGetAllVisualStatesForGroupAndTier(visualStateGroupName, tierToAggregate))
                    {
                        VisualState aggregatedVisualState;

                        if (!aggregatedVisualStates.TryGetValue(visualState.Name, out aggregatedVisualState))
                        {
                            aggregatedVisualState = new VisualState
                            {
                                Name = visualState.Name,
                                Storyboard = new Storyboard()
                            };
                            aggregatedVisualStates[visualState.Name] = aggregatedVisualState;
                        }

                        if (visualState.Storyboard == null)
                        {
                            continue;
                        }

                        aggregatedVisualState.Storyboard.Children.Add(visualState.Storyboard);
                    }
                }

                return aggregatedVisualStates.Values;
            }

            /// <summary>
            /// Gets all visual transitions in a given visual state group and tier, optionally aggregating lower tiers.
            /// </summary>
            /// <param name="visualStateGroupName">
            /// The name of the visual state group.
            /// </param>
            /// <param name="tier">
            /// The maximum tier in which visual transitions may be returned.
            /// </param>
            /// <param name="aggregate">
            /// <see langword="true"/> to aggregate lower tiers.
            /// </param>
            /// <returns>
            /// All relevant visual transitions.
            /// </returns>
            public IEnumerable<VisualTransition> GetAllVisualTransitions(string visualStateGroupName, TierWithNone tier, bool aggregate)
            {
                if (!aggregate)
                {
                    // if we're not aggregating just return all visual transitions assigned to the tier, then all assigned to no particular tier
                    var visualTransitionsInTier = this.SafeGetAllVisualTransitionsForGroupAndTier(visualStateGroupName, tier);
                    var visualTransitionsInNoTier = this.SafeGetAllVisualTransitionsForGroupAndTier(visualStateGroupName, TierWithNone.None);

                    return visualTransitionsInTier.Concat(visualTransitionsInNoTier);
                }

                // if we're aggregating, we need to combine visual transitions in all tiers at or below the specified tier, in order from lowest to highest
                var aggregatedVisualTransitions = new Dictionary<string, VisualTransition>();

                for (var tierToAggregate = TierWithNone.None; tierToAggregate <= tier; ++tierToAggregate)
                {
                    foreach (var visualTransition in this.SafeGetAllVisualTransitionsForGroupAndTier(visualStateGroupName, tierToAggregate))
                    {
                        VisualTransition aggregatedVisualTransition;
                        var key = GetKeyForVisualTransition(visualTransition);

                        if (!aggregatedVisualTransitions.TryGetValue(key, out aggregatedVisualTransition))
                        {
                            aggregatedVisualTransition = new VisualTransition
                            {
                                From = visualTransition.From,
                                To = visualTransition.To,
                                GeneratedDuration = visualTransition.GeneratedDuration,
                                Storyboard = new Storyboard()
                            };
                            aggregatedVisualTransitions[key] = aggregatedVisualTransition;
                        }

                        if (visualTransition.Storyboard == null)
                        {
                            continue;
                        }

                        aggregatedVisualTransition.Storyboard.Children.Add(visualTransition.Storyboard);
                    }
                }

                return aggregatedVisualTransitions.Values;
            }

            private IEnumerable<VisualState> SafeGetAllVisualStatesForGroupAndTier(string visualStateGroupName, TierWithNone tier)
            {
                if (this.VisualStatesByTier.ContainsKey(tier))
                {
                    foreach (var visualState in this.VisualStatesByTier[tier])
                    {
                        if (visualState.Name == null)
                        {
                            continue;
                        }

                        if (this.VisualStateToVisualStateGroupMap[visualState.Name].Name != visualStateGroupName)
                        {
                            continue;
                        }

                        yield return visualState;
                    }
                }
            }

            private IEnumerable<VisualTransition> SafeGetAllVisualTransitionsForGroupAndTier(string visualStateGroupName, TierWithNone tier)
            {
                if (this.VisualTransitionsByTier.ContainsKey(tier))
                {
                    foreach (var visualTransition in this.VisualTransitionsByTier[tier])
                    {
                        if (this.VisualTransitionToVisualStateGroupMap[GetKeyForVisualTransition(visualTransition)].Name != visualStateGroupName)
                        {
                            continue;
                        }

                        yield return visualTransition;
                    }
                }
            }
        }
    }
}