﻿namespace TieredExperience
{
    /// <summary>
    /// Defines possible tiers of experience as used by the <see cref="TieredVisualStateManager"/>.
    /// </summary>
    public enum Tier
    {
        /// <summary>
        /// The lowest possible level of experience.
        /// </summary>
        Low,

        /// <summary>
        /// A medium level of experience.
        /// </summary>
        Medium,

        /// <summary>
        /// The highest possible level of experience.
        /// </summary>
        High
    }
}