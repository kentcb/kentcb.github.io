﻿using System.Windows;
using System.Windows.Markup;

namespace TieredExperience
{
    /// <summary>
    /// A <see cref="VisualStateGroup"/> that is assigned to a particular tier of experience.
    /// </summary>
    [RuntimeNameProperty("NonExistantProperty")]    // HACK: allow us to give non-unique names to TieredVisualStateGroups, since it's the combination of their name and Tier that need be unique
    public class TieredVisualStateGroup : VisualStateGroup
    {
        /// <summary>
        /// Identifies the <see cref="Tier"/> property.
        /// </summary>
        public static readonly DependencyProperty TierProperty = DependencyProperty.Register(
            "Tier",
            typeof(Tier),
            typeof(TieredVisualStateGroup));

        /// <summary>
        /// Gets or sets the tier to which this tiered visual state group belongs.
        /// </summary>
        public Tier Tier
        {
            get { return (Tier)this.GetValue(TierProperty); }
            set { this.SetValue(TierProperty, value); }
        }
    }
}