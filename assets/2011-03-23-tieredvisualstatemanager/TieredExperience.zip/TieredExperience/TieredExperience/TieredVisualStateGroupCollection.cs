﻿using System.Collections.ObjectModel;

namespace TieredExperience
{
    /// <summary>
    /// Implements a collection of <see cref="TieredVisualStateGroup"/>s.
    /// </summary>
    public class TieredVisualStateGroupCollection : ObservableCollection<TieredVisualStateGroup>
    {
    }
}