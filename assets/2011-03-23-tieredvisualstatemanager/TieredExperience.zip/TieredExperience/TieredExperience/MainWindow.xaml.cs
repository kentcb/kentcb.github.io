﻿using System.Collections.Generic;
using System.Windows;

namespace TieredExperience
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public static readonly DependencyProperty LevelsProperty = DependencyProperty.Register(
            "Levels",
            typeof(ICollection<Tier>),
            typeof(MainWindow));

        public static readonly DependencyProperty SelectedLevelProperty = DependencyProperty.Register(
            "SelectedLevel",
            typeof(Tier),
            typeof(MainWindow),
            new FrameworkPropertyMetadata(OnSelectedLevelChanged));

        public MainWindow()
        {
            InitializeComponent();

            this.Levels = new List<Tier>
            {
                Tier.High,
                Tier.Medium,
                Tier.Low
            };
            this.SelectedLevel = Tier.Low;

            this.DataContext = this;
        }

        public ICollection<Tier> Levels
        {
            get { return (ICollection<Tier>)this.GetValue(LevelsProperty); }
            set { this.SetValue(LevelsProperty, value); }
        }

        public Tier SelectedLevel
        {
            get { return (Tier)this.GetValue(SelectedLevelProperty); }
            set { this.SetValue(SelectedLevelProperty, value); }
        }

        private static void OnSelectedLevelChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            TieredVisualStateManager.ActiveTier = (Tier)e.NewValue;
        }
    }
}
