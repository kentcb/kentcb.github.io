﻿using System.Windows;
using System.Windows.Markup;

namespace TieredExperience
{
    /// <summary>
    /// Extends <see cref="VisualState"/> in order to accommodate visual states with the same name.
    /// </summary>
    [RuntimeNameProperty("NonExistantProperty")]    // HACK: allow us to give non-unique names to TieredVisualStates
    public class TieredVisualState : VisualState
    {
    }
}