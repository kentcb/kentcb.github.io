﻿namespace WindowItemsControlDemo.ViewModels
{
    using WindowItemsControlDemo.Mvvm;

    public sealed class ItemViewModel : ViewModel
    {
        private string title;
        private string content;

        public string Title
        {
            get { return this.title; }
            set
            {
                if (this.title != value)
                {
                    this.title = value;
                    this.OnPropertyChanged("Title");
                }
            }
        }

        public string Content
        {
            get { return this.content; }
            set
            {
                if (this.content != value)
                {
                    this.content = value;
                    this.OnPropertyChanged("Content");
                }
            }
        }
    }
}