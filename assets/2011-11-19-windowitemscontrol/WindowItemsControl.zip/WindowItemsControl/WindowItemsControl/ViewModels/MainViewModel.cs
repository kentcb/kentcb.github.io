﻿namespace WindowItemsControlDemo.ViewModels
{
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Windows.Input;
    using WindowItemsControlDemo.Mvvm;

    public sealed class MainViewModel : ViewModel
    {
        private readonly ICollection<ItemViewModel> items;
        private readonly ICommand addItemCommand;
        private readonly ICommand deleteItemCommand;
        private ItemViewModel selectedItem;
        private int itemCounter;

        public MainViewModel()
        {
            this.items = new ObservableCollection<ItemViewModel>();
            this.addItemCommand = new DelegateCommand(this.OnAddItem);
            this.deleteItemCommand = new DelegateCommand(this.OnDeleteItem, this.OnCanDeleteItem);

            // add a few items by default
            this.OnAddItem(null);
            this.OnAddItem(null);
            this.OnAddItem(null);
        }

        public ICollection<ItemViewModel> Items
        {
            get { return this.items; }
        }

        public ICommand AddItemCommand
        {
            get { return this.addItemCommand; }
        }

        public ICommand DeleteItemCommand
        {
            get { return this.deleteItemCommand; }
        }

        public ItemViewModel SelectedItem
        {
            get { return this.selectedItem; }
            set
            {
                if (this.selectedItem != value)
                {
                    this.selectedItem = value;
                    this.OnPropertyChanged("SelectedItem");
                }
            }
        }

        private void OnAddItem(object parameter)
        {
            this.items.Add(new ItemViewModel
                {
                    Title = "Item " + itemCounter,
                    Content = "This is the content for item " + itemCounter
                });

            ++this.itemCounter;
        }

        private void OnDeleteItem(object parameter)
        {
            if (this.SelectedItem == null)
            {
                return;
            }

            this.items.Remove(this.SelectedItem);
        }

        private bool OnCanDeleteItem(object parameter)
        {
            return this.selectedItem != null;
        }
    }
}