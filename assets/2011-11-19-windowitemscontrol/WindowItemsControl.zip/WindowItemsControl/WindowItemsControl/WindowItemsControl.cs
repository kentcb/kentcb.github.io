﻿namespace WindowItemsControlDemo
{
    using System.Diagnostics.CodeAnalysis;
    using System.Windows;
    using System.Windows.Controls;

    /// <summary>
    /// An <see cref="ItemsControl"/> that hosts each item inside a <see cref="Window"/> rather than inline in the visual tree.
    /// </summary>
    public class WindowItemsControl : ItemsControl
    {
        /// <summary>
        /// Identifies the <see cref="ShowDialog"/> property.
        /// </summary>
        public static readonly DependencyProperty ShowDialogProperty = DependencyProperty.Register(
            "ShowDialog",
            typeof(bool),
            typeof(WindowItemsControl));

        /// <summary>
        /// Identifies the <see cref="Owner"/> property.
        /// </summary>
        public static readonly DependencyProperty OwnerProperty = DependencyProperty.Register(
            "Owner",
            typeof(Window),
            typeof(WindowItemsControl),
            new FrameworkPropertyMetadata(OnOwnerChanged));

        /// <summary>
        /// Identifies the <see cref="WindowStartupLocation"/> property.
        /// </summary>
        public static readonly DependencyProperty WindowStartupLocationProperty = DependencyProperty.Register(
            "WindowStartupLocation",
            typeof(WindowStartupLocation),
            typeof(WindowItemsControl));

        /// <summary>
        /// Identifies the <see cref="RemoveDataItemWhenWindowClosed"/> property.
        /// </summary>
        public static readonly DependencyProperty RemoveDataItemWhenWindowClosedProperty = DependencyProperty.Register(
            "RemoveDataItemWhenWindowClosed",
            typeof(bool),
            typeof(WindowItemsControl),
            new FrameworkPropertyMetadata(true));

        [SuppressMessage("Microsoft.Performance", "CA1810", Justification = "Cannot do this inline.")]
        static WindowItemsControl()
        {
            DefaultStyleKeyProperty.OverrideMetadata(typeof(WindowItemsControl), new FrameworkPropertyMetadata(typeof(WindowItemsControl)));
        }

        /// <summary>
        /// Gets or sets a value indicating whether the <see cref="Window"/>s displayed by this <c>WindowItemsControl</c> will be shown modally or modelessly.
        /// </summary>
        public bool ShowDialog
        {
            get { return (bool)this.GetValue(ShowDialogProperty); }
            set { this.SetValue(ShowDialogProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value specifying the owner <see cref="Window"/>, if any, for any <see cref="Window"/> displayed by this <c>WindowItemsControl</c>.
        /// </summary>
        public Window Owner
        {
            get { return this.GetValue(OwnerProperty) as Window; }
            set { this.SetValue(OwnerProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating the desired startup location for any <see cref="Window"/> displayed by this <c>WindowItemsControl</c>.
        /// </summary>
        public WindowStartupLocation WindowStartupLocation
        {
            get { return (WindowStartupLocation)this.GetValue(WindowStartupLocationProperty); }
            set { this.SetValue(WindowStartupLocationProperty, value); }
        }

        /// <summary>
        /// Gets or sets a value indicating whether the related data item should be removed from the <c>Items</c> collection when its <see cref="Window"/> is
        /// closed.
        /// </summary>
        public bool RemoveDataItemWhenWindowClosed
        {
            get { return (bool)this.GetValue(RemoveDataItemWhenWindowClosedProperty); }
            set { this.SetValue(RemoveDataItemWhenWindowClosedProperty, value); }
        }

        /// <inheritdoc/>
        protected override DependencyObject GetContainerForItemOverride()
        {
            return new WindowItemsControlItem(this);
        }

        /// <inheritdoc/>
        protected override bool IsItemItsOwnContainerOverride(object item)
        {
            return item is WindowItemsControlItem;
        }

        /// <inheritdoc/>
        protected override void PrepareContainerForItemOverride(DependencyObject element, object item)
        {
            (element as WindowItemsControlItem).Window.Content = item;
        }

        /// <inheritdoc/>
        protected override bool ShouldApplyItemContainerStyle(DependencyObject container, object item)
        {
            // the item container style will be applied to the windows, not to the containers (which are surrogates for the window)
            return false;
        }

        private static void OnOwnerChanged(DependencyObject dependencyObject, DependencyPropertyChangedEventArgs e)
        {
            var windowItemsControl = (WindowItemsControl)dependencyObject;
            var owner = (Window)e.NewValue;

            for (var i = 0; i < windowItemsControl.Items.Count; ++i)
            {
                var container = windowItemsControl.ItemContainerGenerator.ContainerFromIndex(i) as WindowItemsControlItem;

                if (container == null)
                {
                    continue;
                }

                container.Window.Owner = owner;
            }
        }
    }
}