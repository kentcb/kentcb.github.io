﻿namespace WindowItemsControlDemo
{
    using System;
    using System.ComponentModel;
    using System.Windows;
    using System.Windows.Data;
    using Kent.Boogaart.HelperTrinity.Extensions;

    /// <summary>
    /// Represents an item inside a <see cref="WindowItemsControl"/>.
    /// </summary>
    /// <remarks>
    /// <para>
    /// Instances of <c>WindowItemsControlItem</c> are surrogates for the actual <see cref="Window"/> they represent. They themselves have zero visual representation,
    /// so will never be seen.
    /// </para>
    /// </remarks>
    public class WindowItemsControlItem : FrameworkElement
    {
        private readonly WindowItemsControl windowItemsControl;
        private readonly Window window;

        static WindowItemsControlItem()
        {
            // there is no need for these items to be visible as they are simply surrogates for the windows that they display
            VisibilityProperty.OverrideMetadata(typeof(WindowItemsControlItem), new FrameworkPropertyMetadata(Visibility.Collapsed));
        }

        /// <summary>
        /// Initializes a new instance of the WindowItemsControlItem class.
        /// </summary>
        /// <param name="windowItemsControl">
        /// The owning <see cref="WindowItemsControl"/>.
        /// </param>
        public WindowItemsControlItem(WindowItemsControl windowItemsControl)
        {
            windowItemsControl.AssertNotNull("windowItemsControl");

            this.windowItemsControl = windowItemsControl;
            this.window = this.CreateWindow(windowItemsControl);

            this.Loaded += delegate
            {
                if (this.windowItemsControl.ShowDialog)
                {
                    this.window.ShowDialog();
                }
                else
                {
                    this.window.Show();
                }
            };

            this.Unloaded += delegate
            {
                this.window.Close();
            };
        }

        /// <summary>
        /// Gets the <see cref="Window"/> that this <c>WindowItemsControlItem</c> represents.
        /// </summary>
        public Window Window
        {
            get { return this.window; }
        }

        private Window CreateWindow(WindowItemsControl windowItemsControl)
        {
            var window = new Window
            {
                Owner = windowItemsControl.Owner,
                WindowStartupLocation = windowItemsControl.WindowStartupLocation
            };

            BindingOperations.SetBinding(window, Window.DataContextProperty, new Binding("Content") { Source = window });
            BindingOperations.SetBinding(window, Window.StyleProperty, new Binding("ItemContainerStyle") { Source = windowItemsControl });
            BindingOperations.SetBinding(window, Window.ContentTemplateProperty, new Binding("ItemTemplate") { Source = windowItemsControl });
            BindingOperations.SetBinding(window, Window.ContentTemplateSelectorProperty, new Binding("ItemTemplateSelector") { Source = windowItemsControl });

            window.Closed += delegate
            {
                // orphan the content because it might be hosted somewhere else later (including in another window)
                window.Content = null;

                // if the window closes, attempt to remove the original item from the underlying collection, which will result in this surrogate being removed too
                if (windowItemsControl.RemoveDataItemWhenWindowClosed)
                {
                    var editableItems = windowItemsControl.Items as IEditableCollectionView;

                    if (editableItems != null && editableItems.CanRemove)
                    {
                        editableItems.Remove(this.DataContext);
                    }
                }
            };

            return window;
        }
    }
}