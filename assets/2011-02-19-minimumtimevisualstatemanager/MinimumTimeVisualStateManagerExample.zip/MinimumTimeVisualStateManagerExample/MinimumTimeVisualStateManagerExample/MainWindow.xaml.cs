﻿using System.Windows;
using MinimumTimeVisualStateManagerExample.ViewModels;

namespace MinimumTimeVisualStateManagerExample
{
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();

            this.mainView.DataContext = new MainViewModel();
        }
    }
}