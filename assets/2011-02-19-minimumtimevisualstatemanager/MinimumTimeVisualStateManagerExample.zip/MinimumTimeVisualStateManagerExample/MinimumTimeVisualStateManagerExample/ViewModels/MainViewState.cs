﻿namespace MinimumTimeVisualStateManagerExample.ViewModels
{
    public enum MainViewState
    {
        None,
        Loading,
        Loaded
    }
}