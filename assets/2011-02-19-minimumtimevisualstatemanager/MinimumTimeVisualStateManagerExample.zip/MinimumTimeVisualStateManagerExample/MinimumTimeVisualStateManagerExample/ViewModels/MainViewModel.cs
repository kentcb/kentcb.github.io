﻿using System;
using System.ComponentModel;
using System.Threading;
using System.Windows.Input;

namespace MinimumTimeVisualStateManagerExample.ViewModels
{
    // there are a lot of bad practices and what-have-you in this class. The point is, it serves to demonstrate
    // how a VM can switch between states and have the view respond accordingly using the VSM
    public sealed class MainViewModel : INotifyPropertyChanged
    {
        private static readonly Random random = new Random();
        private readonly ICommand reloadDataCommand;
        private MainViewState state;

        public MainViewModel()
        {
            this.reloadDataCommand = new ReloadDataCommandImpl(this);
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public ICommand ReloadDataCommand
        {
            get { return this.reloadDataCommand; }
        }

        public MainViewState State
        {
            get { return this.state; }
            set
            {
                if (this.state != value)
                {
                    this.state = value;
                    this.OnPropertyChanged("State");
                }
            }
        }

        public void LoadData()
        {
            this.State = MainViewState.Loading;
            ThreadPool.QueueUserWorkItem(delegate
                                         {
                                             // data takes between 0.1 and 2 seconds to load
                                             Thread.Sleep(random.Next(100, 2000));
                                             this.State = MainViewState.Loaded;
                                         });
        }

        private void OnPropertyChanged(string propertyName)
        {
            var handler = this.PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }

        private sealed class ReloadDataCommandImpl : ICommand
        {
            private readonly MainViewModel mainViewModel;

            public ReloadDataCommandImpl(MainViewModel mainViewModel)
            {
                this.mainViewModel = mainViewModel;
            }

            public event EventHandler CanExecuteChanged;

            public bool CanExecute(object parameter)
            {
                return true;
            }

            public void Execute(object parameter)
            {
                mainViewModel.LoadData();
            }
        }
    }
}