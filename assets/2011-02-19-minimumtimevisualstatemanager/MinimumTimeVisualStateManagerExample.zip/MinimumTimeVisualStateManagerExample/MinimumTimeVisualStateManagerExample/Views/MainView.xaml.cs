﻿using System.Threading;
using System.Windows;
using System.Windows.Controls;
using MinimumTimeVisualStateManagerExample.ViewModels;

namespace MinimumTimeVisualStateManagerExample.Views
{
    public partial class MainView : UserControl
    {
        public MainView()
        {
            InitializeComponent();

            var firstTime = true;

            // I normally do this with an attached behavior, but you get the idea
            // it's just listening to changes in the VM and applying the new state to the root grid of our view
            base.Loaded += delegate
            {
                ViewModel.PropertyChanged += delegate
                {
                    Dispatcher.BeginInvoke((ThreadStart)delegate
                    {
                        // either will work. MSDN docs aren't clear on whether there is a functional or only semantic difference
                        // between the two. firstTime is used to ensure transitions don't occur when we first load
                        VisualStateManager.GoToElementState(
                            this.root,
                            this.ViewModel.State.ToString(),
                            !firstTime);
                        //VisualStateManager.GoToState(
                        //    this,
                        //    this.ViewModel.State.ToString(),
                        //    !firstTime);

                        firstTime = false;
                    });
                };
                ViewModel.LoadData();
            };
        }

        private MainViewModel ViewModel
        {
            get { return this.DataContext as MainViewModel; }
        }
    }
}