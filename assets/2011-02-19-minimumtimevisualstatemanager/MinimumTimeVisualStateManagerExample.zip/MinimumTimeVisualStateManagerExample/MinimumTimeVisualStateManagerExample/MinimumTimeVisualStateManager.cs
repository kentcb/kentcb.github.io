﻿using System;
using System.Diagnostics;
using System.Windows;
using System.Windows.Threading;

namespace MinimumTimeVisualStateManagerExample
{
    // a VisualStateManager that can impose a minimum time that a control remains in a state
    public class MinimumTimeVisualStateManager : VisualStateManager
    {
        public static readonly DependencyProperty MinimumTimeProperty = DependencyProperty.RegisterAttached("MinimumTime",
            typeof(TimeSpan),
            typeof(MinimumTimeVisualStateManager),
            new PropertyMetadata(TimeSpan.Zero));

        private static readonly DependencyProperty StateChangeMinimumTimeProperty = DependencyProperty.RegisterAttached("StateChangeMinimumTime",
            typeof(DateTime),
            typeof(MinimumTimeVisualStateManager),
            new PropertyMetadata(DateTime.MinValue));

        public static TimeSpan GetMinimumTime(VisualState visualState)
        {
            if (visualState == null)
            {
                throw new ArgumentNullException("visualState");
            }

            return (TimeSpan)visualState.GetValue(MinimumTimeProperty);
        }

        public static void SetMinimumTime(VisualState visualState, TimeSpan minimumTime)
        {
            if (visualState == null)
            {
                throw new ArgumentNullException("visualState");
            }

            visualState.SetValue(MinimumTimeProperty, minimumTime);
        }

        private static DateTime GetStateChangeMinimumTime(DependencyObject dependencyObject)
        {
            Debug.Assert(dependencyObject != null);
            return (DateTime)dependencyObject.GetValue(StateChangeMinimumTimeProperty);
        }

        private static void SetStateChangeMinimumTime(DependencyObject dependencyObject, DateTime stateChangeMinimumTime)
        {
            Debug.Assert(dependencyObject != null);
            dependencyObject.SetValue(StateChangeMinimumTimeProperty, stateChangeMinimumTime);
        }

        protected override bool GoToStateCore(FrameworkElement control, FrameworkElement stateGroupsRoot, string stateName, VisualStateGroup group, VisualState state, bool useTransitions)
        {
            Debug.Assert(group != null && state != null && stateGroupsRoot != null, "Group, state, or stateGroupsRoot is null for state name '" + stateName + "'. Be sure you've declared the state in the XAML.");

            var minimumTimeToStateChange = GetStateChangeMinimumTime(stateGroupsRoot);

            if (DateTime.UtcNow < minimumTimeToStateChange)
            {
                // can't transition yet so reschedule for later
                var dispatcherTimer = new DispatcherTimer();
                dispatcherTimer.Interval = minimumTimeToStateChange - DateTime.UtcNow;
                dispatcherTimer.Tick += delegate
                {
                    dispatcherTimer.Stop();
                    this.DoStateChange(control, stateGroupsRoot, stateName, group, state, useTransitions);
                };
                dispatcherTimer.Start();

                return false;
            }

            return this.DoStateChange(control, stateGroupsRoot, stateName, group, state, useTransitions);
        }

        private bool DoStateChange(FrameworkElement control, FrameworkElement stateGroupsRoot, string stateName, VisualStateGroup group, VisualState state, bool useTransitions)
        {
            var succeeded = base.GoToStateCore(control, stateGroupsRoot, stateName, group, state, useTransitions);

            if (succeeded)
            {
                SetStateChangeMinimumTime(stateGroupsRoot, DateTime.MinValue);
                var minimumTimeInState = GetMinimumTime(state);

                if (minimumTimeInState > TimeSpan.Zero)
                {
                    SetStateChangeMinimumTime(stateGroupsRoot, DateTime.UtcNow + minimumTimeInState);
                }
            }

            return succeeded;
        }
    }
}