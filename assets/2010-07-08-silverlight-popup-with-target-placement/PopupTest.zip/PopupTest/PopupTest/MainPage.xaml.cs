﻿namespace PopupTest
{
    using System.Collections.Generic;
    using System.ComponentModel;
    using System.Windows;
    using System.Windows.Controls;
    using System.Windows.Controls.Primitives;

    public partial class MainPage : UserControl, INotifyPropertyChanged
    {
        private readonly ICollection<PlacementMode> placementModes;
        private readonly ICollection<HorizontalAlignment> horizontalAlignments;
        private readonly ICollection<VerticalAlignment> verticalAlignments;
        private PlacementMode selectedPlacementMode;
        private HorizontalAlignment selectedHorizontalAlignment;
        private VerticalAlignment selectedVerticalAlignment;

        public MainPage()
        {
            this.placementModes = new List<PlacementMode>(new PlacementMode[] { PlacementMode.Top, PlacementMode.Bottom, PlacementMode.Left, PlacementMode.Right });
            this.horizontalAlignments = new List<HorizontalAlignment>(new HorizontalAlignment[] { HorizontalAlignment.Left, HorizontalAlignment.Center, HorizontalAlignment.Right });
            this.verticalAlignments = new List<VerticalAlignment>(new VerticalAlignment[] { VerticalAlignment.Top, VerticalAlignment.Center, VerticalAlignment.Bottom });
            this.selectedPlacementMode = PlacementMode.Top;
            this.selectedHorizontalAlignment = HorizontalAlignment.Center;
            this.selectedVerticalAlignment = VerticalAlignment.Center;

            this.DataContext = this;

            InitializeComponent();
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public ICollection<PlacementMode> PlacementModes
        {
            get { return this.placementModes; }
        }

        public ICollection<HorizontalAlignment> HorizontalAlignments
        {
            get { return this.horizontalAlignments; }
        }

        public ICollection<VerticalAlignment> VerticalAlignments
        {
            get { return this.verticalAlignments; }
        }

        public PlacementMode SelectedPlacementMode
        {
            get { return this.selectedPlacementMode; }
            set
            {
                this.selectedPlacementMode = value;
                this.OnPropertyChanged("SelectedPlacementMode");
            }
        }

        public HorizontalAlignment SelectedHorizontalAlignment
        {
            get { return this.selectedHorizontalAlignment; }
            set
            {
                this.selectedHorizontalAlignment = value;
                this.OnPropertyChanged("SelectedHorizontalAlignment");
            }
        }

        public VerticalAlignment SelectedVerticalAlignment
        {
            get { return this.selectedVerticalAlignment; }
            set
            {
                this.selectedVerticalAlignment = value;
                this.OnPropertyChanged("SelectedVerticalAlignment");
            }
        }

        private void OnPropertyChanged(string propertyName)
        {
            var handler = this.PropertyChanged;

            if (handler != null)
            {
                handler(this, new PropertyChangedEventArgs(propertyName));
            }
        }
    }
}