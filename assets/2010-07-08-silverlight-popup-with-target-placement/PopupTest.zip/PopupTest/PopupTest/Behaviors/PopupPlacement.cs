﻿namespace PopupTest.Behaviors
{
    public enum PopupPlacement
    {
        Top,
        Bottom,
        Left,
        Right
    }
}