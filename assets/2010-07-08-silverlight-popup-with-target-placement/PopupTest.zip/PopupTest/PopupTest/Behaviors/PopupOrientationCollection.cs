﻿namespace PopupTest.Behaviors
{
    using System.Collections.ObjectModel;

    public class PopupOrientationCollection : Collection<PopupOrientation>
    {
    }
}