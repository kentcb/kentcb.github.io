using System;
using System.Collections.Generic;
using System.Text;
using Sample.Data;
using Sertool;

namespace Sample
{
	class Program
	{
		static void Main(string[] args)
		{
			#region Create data to be serialized

			Artist rammstein = new Artist("Rammstein");

			Album herzeleid = new Album("Herzeleid");
			herzeleid.Tracks.Add(new Track("Wollt ihr das Bett in Flammen sehen?", new TimeSpan(0, 5, 17)));
			herzeleid.Tracks.Add(new Track("Der Meister", new TimeSpan(0, 4, 8)));
			herzeleid.Tracks.Add(new Track("Wei�es Fleisch", new TimeSpan(0, 3, 35)));
			herzeleid.Tracks.Add(new Track("Asche zu Asche", new TimeSpan(0, 3, 51)));
			herzeleid.Tracks.Add(new Track("Seemann", new TimeSpan(0, 4, 48)));
			herzeleid.Tracks.Add(new Track("Du riechst so gut", new TimeSpan(0, 4, 49)));
			herzeleid.Tracks.Add(new Track("Das alte Leid", new TimeSpan(0, 5, 44)));
			herzeleid.Tracks.Add(new Track("Heirate mich", new TimeSpan(0, 4, 44)));
			herzeleid.Tracks.Add(new Track("Herzeleid", new TimeSpan(0, 3, 41)));
			herzeleid.Tracks.Add(new Track("Laichzeit", new TimeSpan(0, 4, 20)));
			herzeleid.Tracks.Add(new Track("Rammstein", new TimeSpan(0, 4, 25)));

			Album sehnsucht = new Album("Sehnsucht");
			sehnsucht.Tracks.Add(new Track("Sehnsucht", new TimeSpan(0, 4, 6)));
			sehnsucht.Tracks.Add(new Track("Engel", new TimeSpan(0, 4, 26)));
			sehnsucht.Tracks.Add(new Track("Tier", new TimeSpan(0, 3, 49)));
			sehnsucht.Tracks.Add(new Track("Bestrafe mich", new TimeSpan(0, 3, 37)));
			sehnsucht.Tracks.Add(new Track("Du hast", new TimeSpan(0, 3, 57)));
			sehnsucht.Tracks.Add(new Track("B�ck dich", new TimeSpan(0, 3, 24)));
			sehnsucht.Tracks.Add(new Track("Spiel mit mir", new TimeSpan(0, 4, 45)));
			sehnsucht.Tracks.Add(new Track("Klavier", new TimeSpan(0, 4, 26)));
			sehnsucht.Tracks.Add(new Track("Alter Mann", new TimeSpan(0, 4, 26)));
			sehnsucht.Tracks.Add(new Track("Eifersucht", new TimeSpan(0, 3, 37)));
			sehnsucht.Tracks.Add(new Track("K�ss mich (Fellfrosch)", new TimeSpan(0, 3, 29)));

			//too lazy to put in other albums, but you get the idea

			rammstein.Albums.Add(herzeleid);
			rammstein.Albums.Add(sehnsucht);

			//put a non-serializable value in one of the track's tags
			sehnsucht.Tracks[3].Tag = new Program();

			//attach a non-serializable event handler to a serialized event
			rammstein.PropertyChanged += new Program().rammstein_PropertyChanged;

			#endregion

			//use sertool to output serialization information to the console
			Sertool.Sertool.OutputSerializationInformation(rammstein);

			Console.ReadKey();
		}

		private void rammstein_PropertyChanged(object sender, System.ComponentModel.PropertyChangedEventArgs e)
		{
			//does nothing but serves as an example of an event handler that cannot be serialized
		}
	}
}
