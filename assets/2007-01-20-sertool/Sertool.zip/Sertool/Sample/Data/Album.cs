using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace Sample.Data
{
	[Serializable]
	public sealed class Album : DataBase, ISerializable
	{
		private string _title;

		public string Title
		{
			get
			{
				return _title;
			}
			set
			{
				if (value != _title)
				{
					_title = value;
					OnPropertyChanged("Title");
				}
			}
		}

		private readonly List<Track> _tracks = new List<Track>();

		public List<Track> Tracks
		{
			get
			{
				return _tracks;
			}
		}

		void ISerializable.GetObjectData(SerializationInfo info, StreamingContext context)
		{
			info.AddValue("title", _title);
			info.AddValue("tracks", _tracks);
		}

		public Album()
		{
		}

		public Album(string title)
		{
			_title = title;
		}

		private Album(SerializationInfo info, StreamingContext context)
		{
			_title = info.GetString("title");
			_tracks = info.GetValue("tracks", typeof(List<Track>)) as List<Track>;
		}
	}
}
