using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;

namespace Sample.Data
{
	[Serializable]
	public sealed class Artist : DataBase
	{
		private string _name;

		public string Name
		{
			get
			{
				return _name;
			}
			set
			{
				if (value != _name)
				{
					_name = value;
					OnPropertyChanged("Name");
				}
			}
		}

		private readonly List<Album> _albums = new List<Album>();

		public List<Album> Albums
		{
			get
			{
				return _albums;
			}
		}

		[NonSerialized]
		private Guid _guid;

		public Guid Guid
		{
			get
			{
				return _guid;
			}
		}

		public Artist()
		{
			_guid = Guid.NewGuid();
		}

		public Artist(string name)
			: this()
		{
			_name = name;
		}

		[OnDeserialized]
		private void OnDeserialized(StreamingContext context)
		{
			_guid = Guid.NewGuid();
		}
	}
}
