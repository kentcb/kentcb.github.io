using System;
using System.Collections.Generic;
using System.Text;

namespace Sample.Data
{
	[Serializable]
	public sealed class Track : DataBase
	{
		private string _title;

		public string Title
		{
			get
			{
				return _title;
			}
			set
			{
				if (value != _title)
				{
					_title = value;
					OnPropertyChanged("Title");
				}
			}
		}

		private TimeSpan _length;

		public TimeSpan Length
		{
			get
			{
				return _length;
			}
			set
			{
				if (value != _length)
				{
					_length = value;
					OnPropertyChanged("Length");
				}
			}
		}

		private object _tag;

		public object Tag
		{
			get
			{
				return _tag;
			}
			set
			{
				if (value != _tag)
				{
					_tag = value;
					OnPropertyChanged("Tag");
				}
			}
		}

		public Track()
		{
		}

		public Track(string title)
		{
			_title = title;
		}

		public Track(string title, TimeSpan length)
			: this(title)
		{
			_length = length;
		}
	}
}
