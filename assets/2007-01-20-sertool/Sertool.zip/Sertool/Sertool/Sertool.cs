using System;
using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Runtime.Serialization;
using System.Text;
using System.Collections.ObjectModel;

namespace Sertool
{
	public static class Sertool
	{
		private const string _idFormat = "X4";
		private const ConsoleColor _idColor = ConsoleColor.Magenta;
		private const ConsoleColor _typeColor = ConsoleColor.DarkCyan;
		private const ConsoleColor _nullColor = ConsoleColor.DarkGray;
		private const ConsoleColor _fieldColor = ConsoleColor.White;
		private const ConsoleColor _fieldSeparatorColor = ConsoleColor.Gray;
		private const ConsoleColor _errorForegroundColor = ConsoleColor.Black;
		private const ConsoleColor _errorBackgroundColor = ConsoleColor.Red;
		private const ConsoleColor _statisticsColor = ConsoleColor.White;

		public static void OutputSerializationInformation(object sourceObject)
		{
			OutputSerializationInformation(sourceObject, Console.Out);
		}

		public static void OutputSerializationInformation(object sourceObject, TextWriter textWriter)
		{
			OutputSerializationInformation(sourceObject, textWriter, new ObjectIDGenerator());
		}

		private static void OutputSerializationInformation(object sourceObject, TextWriter textWriter, ObjectIDGenerator objectIDGenerator)
		{
			bool isConsoleInUse = object.ReferenceEquals(textWriter, Console.Out);
			Queue<object> objectsToVisit = new Queue<object>();
			IDictionary<object, long> valueInstancesAlreadyVisited = new Dictionary<object, long>();
			int totalVisitedObjects = 0;
			int totalSerializableInstances = 0;
			int totalSerializationErrors = 0;

			if (sourceObject != null)
			{
				objectsToVisit.Enqueue(sourceObject);
			}

			while (objectsToVisit.Count > 0)
			{
				++totalVisitedObjects;
				bool firstTime;
				object objectToVisit = objectsToVisit.Dequeue();
				long objectId = objectIDGenerator.GetId(objectToVisit, out firstTime);
				SerializedMemberInfos serializedMemberInfos = new SerializedMemberInfos();
				Exception serializationError = null;

				try
				{
					PopulateSerializedMemberInfo(objectToVisit, serializedMemberInfos);

					if (objectToVisit is ISerializable)
					{
						++totalSerializableInstances;
					}
				}
				catch (SerializationException ex)
				{
					++totalSerializationErrors;
					serializationError = ex;
				}

				using (ColoredConsole.Foreground(isConsoleInUse, _idColor))
				{
					textWriter.Write(objectId.ToString(_idFormat));
				}

				textWriter.Write(" ");

				using (ColoredConsole.Foreground(isConsoleInUse, _typeColor))
				{
					textWriter.Write(objectToVisit.GetType().FullName);
				}

				if (objectToVisit is ISerializable)
				{
					textWriter.Write(" [S]");
				}

				textWriter.WriteLine();

				if (serializationError == null)
				{
					foreach (SerializedMemberInfo serializedMemberInfo in serializedMemberInfos)
					{
						long serializedMemberObjectId = -1;

						if (serializedMemberInfo.Value != null)
						{
							if (serializedMemberInfo.Type.IsValueType)
							{
								if (!valueInstancesAlreadyVisited.TryGetValue(serializedMemberInfo.Value, out serializedMemberObjectId))
								{
									serializedMemberObjectId = objectIDGenerator.GetId(serializedMemberInfo.Value, out firstTime);
									valueInstancesAlreadyVisited[serializedMemberInfo.Value] = serializedMemberObjectId;
									objectsToVisit.Enqueue(serializedMemberInfo.Value);
								}
							}
							else
							{
								serializedMemberObjectId = objectIDGenerator.GetId(serializedMemberInfo.Value, out firstTime);

								if (firstTime)
								{
									objectsToVisit.Enqueue(serializedMemberInfo.Value);
								}
							}
						}

						textWriter.Write("    ");

						using (ColoredConsole.Foreground(isConsoleInUse, _fieldColor))
						{
							textWriter.Write("{0,-" + serializedMemberInfos.MaximumNameLength + "}", serializedMemberInfo.Name);
						}

						using (ColoredConsole.Foreground(isConsoleInUse, _fieldSeparatorColor))
						{
							textWriter.Write(" -> ");
						}

						if (serializedMemberInfo.Value != null)
						{
							using (ColoredConsole.Foreground(isConsoleInUse, _idColor))
							{
								textWriter.Write(serializedMemberObjectId.ToString(_idFormat));
							}
						}
						else
						{
							using (ColoredConsole.Foreground(isConsoleInUse, _nullColor))
							{
								textWriter.Write("NULL");
							}
						}

						textWriter.Write(" ");

						using (ColoredConsole.Foreground(isConsoleInUse, _typeColor))
						{
							textWriter.Write(serializedMemberInfo.Type.FullName);
						}

						textWriter.WriteLine();
					}
				}
				else
				{
					using (ColoredConsole.ForegroundAndBackground(isConsoleInUse, _errorForegroundColor, _errorBackgroundColor))
					{
						textWriter.Write(serializationError.Message);
					}

					textWriter.WriteLine();
				}

				textWriter.WriteLine();
			}

			using (ColoredConsole.Foreground(isConsoleInUse, _statisticsColor))
			{
				textWriter.WriteLine("Total objects in serialization graph: {0}", totalVisitedObjects);
				textWriter.WriteLine("Total reference type instances: {0}", totalVisitedObjects - valueInstancesAlreadyVisited.Count);
				textWriter.WriteLine("Total value type instances: {0}", valueInstancesAlreadyVisited.Count);
				textWriter.WriteLine("Total ISerializable type instances: {0}", totalSerializableInstances);
				textWriter.WriteLine("Total non-ISerializable type instances: {0}", totalVisitedObjects - totalSerializableInstances);
				textWriter.WriteLine("Total serialization errors: {0}", totalSerializationErrors);
			}
		}

		private static void PopulateSerializedMemberInfo(object objectToVisit, SerializedMemberInfos serializedMemberInfos)
		{
			if (objectToVisit.GetType().IsArray)
			{
				Array array = (Array) objectToVisit;
				int index = 0;

				foreach (object o in array)
				{
					serializedMemberInfos.Add(new SerializedMemberInfo(index.ToString(), objectToVisit.GetType().GetElementType(), o));
					++index;
				}
			}
			else if (objectToVisit is ISerializable)
			{
				ISerializable serializable = objectToVisit as ISerializable;
				SerializationInfo serializationInfo = new SerializationInfo(objectToVisit.GetType(), new FormatterConverter());
				serializable.GetObjectData(serializationInfo, new StreamingContext());
				SerializationInfoEnumerator serializationInfoEnumerator = serializationInfo.GetEnumerator();

				while (serializationInfoEnumerator.MoveNext())
				{
					serializedMemberInfos.Add(new SerializedMemberInfo(serializationInfoEnumerator.Current.Name, serializationInfoEnumerator.Current.ObjectType, serializationInfoEnumerator.Current.Value));
				}
			}
			else
			{
				System.Diagnostics.Debug.Assert(!(objectToVisit is ISerializable));
				MemberInfo[] serializableMembers = FormatterServices.GetSerializableMembers(objectToVisit.GetType());

				if (serializableMembers.Length > 0)
				{
					object[] serializableMemberData = FormatterServices.GetObjectData(objectToVisit, serializableMembers);

					for (int i = 0; i < serializableMembers.Length; ++i)
					{
						FieldInfo fieldInfo = serializableMembers[i] as FieldInfo;
						object data = serializableMemberData[i];
						serializedMemberInfos.Add(new SerializedMemberInfo(fieldInfo.Name, fieldInfo.FieldType, data));
					}
				}
			}
		}

		private struct SerializedMemberInfo
		{
			public string Name;
			public Type Type;
			public object Value;

			public SerializedMemberInfo(string name, Type type, object value)
			{
				Name = name;
				Type = type;
				Value = value;
			}
		}

		private sealed class SerializedMemberInfos : Collection<SerializedMemberInfo>
		{
			private int _maximumNameLength;

			public int MaximumNameLength
			{
				get
				{
					return _maximumNameLength;
				}
			}

			protected override void InsertItem(int index, SerializedMemberInfo item)
			{
				base.InsertItem(index, item);
				_maximumNameLength = Math.Max(_maximumNameLength, item.Name.Length);
			}
		}

		private sealed class ColoredConsole : IDisposable
		{
			private readonly ConsoleColor? _foreground;
			private readonly ConsoleColor? _background;
			private bool _disposed;

			private ColoredConsole(ConsoleColor? foreground, ConsoleColor? background)
			{
				if (foreground.HasValue)
				{
					_foreground = Console.ForegroundColor;
					Console.ForegroundColor = foreground.Value;
				}

				if (background.HasValue)
				{
					_background = Console.BackgroundColor;
					Console.BackgroundColor = background.Value;
				}
			}

			public static IDisposable Foreground(bool isConsoleInUse, ConsoleColor foreground)
			{
				if (isConsoleInUse)
				{
					return new ColoredConsole(foreground, null);
				}
				else
				{
					return DummyDisposable.Instance;
				}
			}

			public static IDisposable Background(bool isConsoleInUse, ConsoleColor background)
			{
				if (isConsoleInUse)
				{
					return new ColoredConsole(null, background);
				}
				else
				{
					return DummyDisposable.Instance;
				}
			}

			public static IDisposable ForegroundAndBackground(bool isConsoleInUse, ConsoleColor foreground, ConsoleColor background)
			{
				if (isConsoleInUse)
				{
					return new ColoredConsole(foreground, background);
				}
				else
				{
					return DummyDisposable.Instance;
				}
			}

			public void Dispose()
			{
				if (!_disposed)
				{
					_disposed = true;

					if (_foreground.HasValue)
					{
						Console.ForegroundColor = _foreground.Value;
					}

					if (_background.HasValue)
					{
						Console.BackgroundColor = _background.Value;
					}
				}
			}
		}

		private sealed class DummyDisposable : IDisposable
		{
			public static readonly DummyDisposable Instance = new DummyDisposable();

			private DummyDisposable()
			{
			}

			public void Dispose()
			{
			}
		}
	}
}
