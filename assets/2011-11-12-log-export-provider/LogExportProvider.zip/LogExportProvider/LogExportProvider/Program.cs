﻿using System;
using System.ComponentModel.Composition;
using System.ComponentModel.Composition.Hosting;
using log4net.Config;

namespace LogExportProvider
{
    class Program
    {
        static void Main(string[] args)
        {
            // configure log4net from our config file
            XmlConfigurator.Configure();

            // create the MEF container
            var catalog = new AssemblyCatalog(typeof(Program).Assembly);
            var compositionContainer = new CompositionContainer(catalog, new LoggerServiceExportProvider());

            // obtain our log consumer and log some stuff
            var logConsumer = compositionContainer.GetExportedValue<LogConsumer>();
            logConsumer.LogSomeStuff();

            Console.WriteLine("Done - press any key to exit. Check the log for output.");
            Console.ReadKey();
        }
    }
    
    [Export]
    class LogConsumer
    {
        private readonly ILoggerService loggerService;

        // all we need to do to get an instance of the logging service is import it
        [ImportingConstructor]
        public LogConsumer(ILoggerService loggerService)
        {
            this.loggerService = loggerService;
        }

        public void LogSomeStuff()
        {
            // all this stuff will appear in the log, and it will be recorded with the correct owner type (LogConsumer)
            using (this.loggerService.Perf("Logging example messages"))
            {
                this.loggerService.Debug("A debug message.");
                this.loggerService.Info("For your information, the time is {0:g}.", DateTime.Now);
                this.loggerService.Error("Something bad happened.", new InvalidOperationException("Don't fret - this exception is just for demo purposes."));
            }
        }
    }
}
