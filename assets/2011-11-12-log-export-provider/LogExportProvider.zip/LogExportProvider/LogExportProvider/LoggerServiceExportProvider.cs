﻿namespace LogExportProvider
{
    using System;
    using System.Collections.Generic;
    using System.ComponentModel.Composition.Hosting;
    using System.ComponentModel.Composition.Primitives;
    using System.ComponentModel.Composition.ReflectionModel;
    using System.Linq;
    using System.Reflection;
    using log4net;

    public sealed class LoggerServiceExportProvider : ExportProvider
    {
        private static readonly ILoggerService log = new Log4NetLoggerService(LogManager.GetLogger(typeof(LoggerServiceExportProvider)));
        private readonly IDictionary<Type, ILoggerService> loggerServiceCache;

        public LoggerServiceExportProvider()
        {
            this.loggerServiceCache = new Dictionary<Type, ILoggerService>();
        }

        protected override IEnumerable<Export> GetExportsCore(ImportDefinition definition, AtomicComposition atomicComposition)
        {
            var contractName = definition.ContractName;

            log.Verbose("Attempting to resolve contract name '{0}' to a log instance.", contractName);

            if (string.IsNullOrEmpty(contractName))
            {
                log.Verbose("Contract name is null or empty - cannot resolve.");
                yield break;
            }

            if (!string.Equals(typeof(ILoggerService).FullName, contractName, StringComparison.Ordinal))
            {
                log.Verbose("Incorrect contract - cannot resolve.");
                yield break;
            }

            if (definition.Cardinality != ImportCardinality.ExactlyOne)
            {
                log.Verbose("Cardinality is {0} - cannot resolve.", definition.Cardinality);
                yield break;
            }

            // in order to get a log4net logger, we need the type importing the logger facade
            Type ownerType = null;

            if (ReflectionModelServices.IsImportingParameter(definition))
            {
                log.Verbose("Parameter import detected.");

                var importingParameter = ReflectionModelServices.GetImportingParameter(definition);
                ownerType = importingParameter.Value.Member.DeclaringType;
            }
            else
            {
                log.Verbose("Property import detected.");

                var setAccessor = ReflectionModelServices
                    .GetImportingMember(definition)
                    .GetAccessors()
                    .Where(x => x is MethodInfo)
                    .Select(x => x as MethodInfo)
                    .FirstOrDefault(x => (x.Attributes & MethodAttributes.SpecialName) == MethodAttributes.SpecialName && x.Name.StartsWith("set_", StringComparison.Ordinal));

                if (setAccessor == null)
                {
                    log.Verbose("Set accessor for property not found - cannot resolve.");
                    yield break;
                }

                ownerType = setAccessor.DeclaringType;
            }

            if (ownerType == null)
            {
                log.Verbose("Owner type could not be determined - cannot resolve.");
                yield break;
            }

            log.Verbose("Owner type is '{0}'.", ownerType.FullName);

            ILoggerService loggerService;

            if (!this.loggerServiceCache.TryGetValue(ownerType, out loggerService))
            {
                log.Verbose("Logger facade for owner type '{0}' is not yet cached - creating it.", ownerType.FullName);

                var logInstance = LogManager.GetLogger(ownerType);
                loggerService = new Log4NetLoggerService(logInstance);
                this.loggerServiceCache[ownerType] = loggerService;
            }

            var export = new Export(contractName, () => loggerService);
            yield return export;
        }
    }
}