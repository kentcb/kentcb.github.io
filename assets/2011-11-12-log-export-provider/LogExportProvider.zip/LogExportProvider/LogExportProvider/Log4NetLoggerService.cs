﻿namespace LogExportProvider
{
    using System;
    using System.Diagnostics;
    using System.Globalization;
    using Kent.Boogaart.HelperTrinity.Extensions;
    using log4net;
    using log4net.Core;
    using log4net.Util;

    public sealed class Log4NetLoggerService : ILoggerService
    {
        private static readonly Level perfLevel = new Level(35000, "PERF");
        private readonly ILog log;

        public Log4NetLoggerService(ILog log)
        {
            log.AssertNotNull("log");
            this.log = log;
        }

        public bool IsVerboseEnabled
        {
            get { return this.log.Logger.IsEnabledFor(Level.Verbose); }
        }

        public bool IsDebugEnabled
        {
            get { return this.log.IsDebugEnabled; }
        }

        public bool IsInfoEnabled
        {
            get { return this.log.IsInfoEnabled; }
        }

        public bool IsWarnEnabled
        {
            get { return this.log.IsWarnEnabled; }
        }

        public bool IsErrorEnabled
        {
            get { return this.log.IsErrorEnabled; }
        }

        public bool IsPerfEnabled
        {
            get { return this.log.Logger.IsEnabledFor(perfLevel); }
        }

        public void Verbose(string message)
        {
            this.log.Logger.Log(typeof(Log4NetLoggerService), Level.Verbose, message, null);
        }

        public void Verbose(string message, Exception exception)
        {
            this.log.Logger.Log(typeof(Log4NetLoggerService), Level.Verbose, message, exception);
        }

        public void Verbose(string message, params object[] args)
        {
            this.log.Logger.Log(typeof(Log4NetLoggerService), Level.Verbose, new SystemStringFormat(CultureInfo.InvariantCulture, message, args), null);
        }

        public void Debug(string message)
        {
            this.log.Debug(message);
        }

        public void Debug(string message, Exception exception)
        {
            this.log.Debug(message, exception);
        }

        public void Debug(string message, params object[] args)
        {
            this.log.DebugFormat(CultureInfo.InvariantCulture, message, args);
        }

        public void Info(string message)
        {
            this.log.Info(message);
        }

        public void Info(string message, Exception exception)
        {
            this.log.Info(message, exception);
        }

        public void Info(string message, params object[] args)
        {
            this.log.InfoFormat(CultureInfo.InvariantCulture, message, args);
        }

        public void Warn(string message)
        {
            this.log.Warn(message);
        }

        public void Warn(string message, Exception exception)
        {
            this.log.Warn(message, exception);
        }

        public void Warn(string message, params object[] args)
        {
            this.log.WarnFormat(CultureInfo.InvariantCulture, message, args);
        }

        public void Error(string message)
        {
            this.log.Error(message);
        }

        public void Error(string message, Exception exception)
        {
            this.log.Error(message, exception);
        }

        public void Error(string message, params object[] args)
        {
            this.log.ErrorFormat(CultureInfo.InvariantCulture, message, args);
        }

        public IDisposable Perf(string message)
        {
            message.AssertNotNull("message");
            return new PerfBlock(this, message);
        }

        public IDisposable Perf(string message, params object[] args)
        {
            message.AssertNotNull("message");
            args.AssertNotNull("args");
            return new PerfBlock(this, string.Format(CultureInfo.InvariantCulture, message, args));
        }

        private sealed class PerfBlock : IDisposable
        {
            private readonly Log4NetLoggerService owner;
            private readonly string message;
            private readonly Stopwatch stopwatch;
            private bool disposed;

            public PerfBlock(Log4NetLoggerService owner, string message)
            {
                this.owner = owner;
                this.message = message;
                this.stopwatch = Stopwatch.StartNew();
            }

            public void Dispose()
            {
                if (!this.disposed)
                {
                    this.disposed = true;
                    this.stopwatch.Stop();
                    var messageWithTimingInfo = string.Format(CultureInfo.InvariantCulture, "{0} [{1}, {2}ms]", this.message, this.stopwatch.Elapsed, this.stopwatch.ElapsedMilliseconds);
                    this.owner.log.Logger.Log(typeof(Log4NetLoggerService), perfLevel, messageWithTimingInfo, null);
                }
            }
        }
    }
}