﻿using System;
using System.Windows;
using System.Windows.Input;

namespace MultiKeyGestureDemo
{
	public partial class Window1 : Window
	{
		public Window1()
		{
			InitializeComponent();
			_textBox.Focus();
		}

		private void _exitExecuted(object sender, EventArgs e)
		{
			Close();
		}

		private void _commandExecuted(object sender, ExecutedRoutedEventArgs e)
		{
			MessageBox.Show("Executed: " + (e.Command as RoutedUICommand).Text);
		}

		private void _secretCommand_Executed(object sender, EventArgs e)
		{
			MessageBox.Show("Damn straight!");
		}
	}
}
