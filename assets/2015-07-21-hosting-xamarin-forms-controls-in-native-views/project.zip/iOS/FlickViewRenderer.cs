﻿[assembly: Xamarin.Forms.ExportRenderer(typeof(HostingXFControlsInNativeViews.FlickView), typeof(HostingXFControlsInNativeViews.iOS.FlickViewRenderer))]

namespace HostingXFControlsInNativeViews.iOS
{
    using System;
    using System.Collections.Generic;
    using System.Linq;
    using System.Reflection;
    using CoreGraphics;
    using UIKit;
    using Xamarin.Forms;
    using Xamarin.Forms.Platform.iOS;

    public class FlickViewRenderer : ViewRenderer<FlickView, UIView>
    {
        private UIScrollView scrollView;
        private IList<IVisualElementRenderer> childRenderers;

        protected override void OnElementChanged(ElementChangedEventArgs<FlickView> e)
        {
            base.OnElementChanged(e);

            if (e.OldElement != null)
            {
                this.scrollView.Dispose();

                foreach (var childRenderer in this.childRenderers)
                {
                    childRenderer.NativeView.RemoveFromSuperview();
                    childRenderer.NativeView.Dispose();
                    childRenderer.Dispose();
                }
            }

            if (e.NewElement != null)
            {
                this.scrollView = new UIScrollView
                {
                    PagingEnabled = true,
                    ShowsHorizontalScrollIndicator = false,
                    ShowsVerticalScrollIndicator = false,
                    ScrollsToTop = false
                };

                this.childRenderers = e
                    .NewElement
                    .Children
                    .Select(RendererFactory.GetRenderer)
                    .ToList();

                // HACK: we have to explicitly pass the platform through to each child element
                var platformProperty = typeof(Element)
                    .GetProperty("Platform", BindingFlags.NonPublic | BindingFlags.Instance);
                var platform = platformProperty
                    .GetValue(this.Element);

                foreach (var childRenderer in this.childRenderers)
                {
                    this.scrollView.AddSubview(childRenderer.NativeView);

                    // HACK: we have to explicitly pass the platform through to each child element
                    platformProperty.SetValue(childRenderer.Element, platform);
                }

                this.SetNativeControl(this.scrollView);
            }
        }

        public override void LayoutSubviews()
        {
            base.LayoutSubviews();

            this.scrollView.Frame = this.Bounds;

            this.scrollView.ContentSize = new CGSize(
                this.scrollView.Frame.Width * this.childRenderers.Count,
                this.scrollView.Frame.Height);

            for (var i = 0; i < this.childRenderers.Count; ++i)
            {
                var childRenderer = this.childRenderers[i];
                var childFrame = this.scrollView.Bounds;
                childFrame.Offset(i * this.scrollView.Frame.Width, 0);
                childRenderer.NativeView.Frame = childFrame;

                childRenderer.Element.Layout(
                    new Rectangle(
                        0,
                        0,
                        this.Bounds.Width,
                        this.Bounds.Height));
            }
        }
    }
}