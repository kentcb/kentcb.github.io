﻿namespace HostingXFControlsInNativeViews
{
    using Xamarin.Forms;

    public class App : Application
    {
        public App()
        {
            MainPage = new MainPage();
        }
    }
}