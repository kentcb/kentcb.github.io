﻿namespace HostingXFControlsInNativeViews
{
    using System.Collections.Generic;
    using Xamarin.Forms;

    [ContentProperty("Children")]
    public class FlickView : View, IViewContainer<View>
    {
        private readonly IList<View> children;

        public FlickView()
        {
            this.children = new List<View>();
        }

        public IList<View> Children
        {
            get { return this.children; }
        }
    }
}