﻿namespace VirtualPaging
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Collections.Specialized;
    using System.ComponentModel;
    using System.Globalization;
    using System.Linq;
    using System.Threading;

    public class LazyAsyncCollectionView<T> : ICollectionView
        where T : class
    {
        private readonly int totalItemCount;
        private readonly int pageSize;
        private readonly Func<int, IEnumerable<T>> getPage;
        private readonly IList<AsyncLazy<T>> items;

        public LazyAsyncCollectionView(int totalItemCount, int pageSize, Func<int, IEnumerable<T>> getPage)
        {
            this.totalItemCount = totalItemCount;
            this.pageSize = pageSize;
            this.getPage = getPage;
            this.items = new List<AsyncLazy<T>>(totalItemCount);

            // SL will iterate over our collection no matter what, so we may as well create the placeholders up-front
            for (var i = 0; i < totalItemCount; ++i)
            {
                var localI = i;
                this.items.Add(new AsyncLazy<T>(() => this.LoadItem(localI)));
            }
        }

        // useful for determining the total number of items and getting the first page all in one shot
        public LazyAsyncCollectionView(int totalItemCount, int pageSize, Func<int, IEnumerable<T>> getPage, IList<T> firstPage)
            : this(totalItemCount, pageSize, getPage)
        {
            for (var i = 0; i < firstPage.Count; ++i)
            {
                this.items[i].Value = firstPage[i];
            }
        }

        public bool CanFilter
        {
            get { return false; }
        }

        public bool CanGroup
        {
            get { return false; }
        }

        public bool CanSort
        {
            get { return false; }
        }

        public bool IsEmpty
        {
            get { return this.totalItemCount == 0; }
        }

        public IEnumerator GetEnumerator()
        {
            return this.items.GetEnumerator();
        }

        private T LoadItem(int index)
        {
            if (!(this.items[index].IsValueCreated))
            {
                var pageNumber = index / this.pageSize;
                var itemToLockOn = this.items[pageNumber * this.pageSize];

                if (!Monitor.TryEnter(itemToLockOn))
                {
                    // this page is already in the process of being loaded by another thread - may as well get out and wait for it to be loaded
                    // the return value here doesn't actually matter because we update it below once the page is loaded
                    return default(T);
                }

                try
                {
                    if (!(this.items[index].IsValueCreated))
                    {
                        try
                        {
                            var page = (this.getPage(pageNumber) ?? Enumerable.Empty<T>()).ToList();

                            for (var i = 0; i < page.Count; ++i)
                            {
                                this.items[(pageNumber * this.pageSize) + i].Value = page[i];
                            }
                        }
                        catch (Exception)
                        {
                            // nothing we can do, really. Maybe retry a couple times?
                        }
                    }
                }
                finally
                {
                    Monitor.Exit(itemToLockOn);
                }
            }

            return this.items[index].Value;
        }

        #region Unsupported (not required for my scenario)

        public event EventHandler CurrentChanged;

        public event CurrentChangingEventHandler CurrentChanging;

        public event NotifyCollectionChangedEventHandler CollectionChanged;

        public CultureInfo Culture
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public Predicate<object> Filter
        {
            get
            {
                throw new NotImplementedException();
            }
            set
            {
                throw new NotImplementedException();
            }
        }

        public ObservableCollection<GroupDescription> GroupDescriptions
        {
            get { throw new NotImplementedException(); }
        }

        public ReadOnlyObservableCollection<object> Groups
        {
            get { throw new NotImplementedException(); }
        }

        public SortDescriptionCollection SortDescriptions
        {
            get { throw new NotImplementedException(); }
        }

        public object CurrentItem
        {
            get { return null; }
        }

        public int CurrentPosition
        {
            get { throw new NotImplementedException(); }
        }

        public bool IsCurrentAfterLast
        {
            get { throw new NotImplementedException(); }
        }

        public bool IsCurrentBeforeFirst
        {
            get { throw new NotImplementedException(); }
        }

        public bool Contains(object item)
        {
            throw new NotImplementedException();
        }

        public IDisposable DeferRefresh()
        {
            throw new NotImplementedException();
        }

        public bool MoveCurrentTo(object item)
        {
            throw new NotImplementedException();
        }

        public bool MoveCurrentToFirst()
        {
            throw new NotImplementedException();
        }

        public bool MoveCurrentToLast()
        {
            throw new NotImplementedException();
        }

        public bool MoveCurrentToNext()
        {
            throw new NotImplementedException();
        }

        public bool MoveCurrentToPosition(int position)
        {
            throw new NotImplementedException();
        }

        public bool MoveCurrentToPrevious()
        {
            throw new NotImplementedException();
        }

        public void Refresh()
        {
            throw new NotImplementedException();
        }

        public IEnumerable SourceCollection
        {
            get { throw new NotImplementedException(); }
        }

        #endregion
    }
}