﻿namespace VirtualPaging
{
    using System;
    using System.ComponentModel;
    using System.Threading;

    public sealed class AsyncLazy<T> : INotifyPropertyChanged
        where T : class
    {
        private static readonly SynchronizationContext synchronizationContext;
        private readonly Func<T> valueFactory;
        private T value;

        static AsyncLazy()
        {
            synchronizationContext = SynchronizationContext.Current;
        }

        public AsyncLazy(Func<T> valueFactory)
        {
            this.valueFactory = valueFactory;
        }

        public event PropertyChangedEventHandler PropertyChanged;

        public T Value
        {
            get
            {
                if (this.value == null)
                {
                    this.LoadValue();
                }

                return this.value;
            }
            set
            {
                if (value == null)
                {
                    // this happens when the value is resolved but another thread is already loading the page
                    // we explicitly check for null to avoid race conditions between the two threads
                    // e.g. page loads, value is set, but then the other thread sets the value back to null
                    return;
                }

                if (this.value != value)
                {
                    this.value = value;
                    this.OnPropertyChanged("Value");
                    this.OnPropertyChanged("IsValueCreated");
                }
            }
        }

        public bool IsValueCreated
        {
            // assumes null is not a valid value, which is true for my scenario
            get { return this.value != null; }
        }

        private void LoadValue()
        {
            ThreadPool.QueueUserWorkItem(delegate
            {
                this.Value = this.valueFactory();
            });
        }

        private void OnPropertyChanged(string propertyName)
        {
            var handler = this.PropertyChanged;

            if (handler != null)
            {
                synchronizationContext.Post(delegate
                {
                    handler(this, new PropertyChangedEventArgs(propertyName));
                }, null);
            }
        }
    }
}
