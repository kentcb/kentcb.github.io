﻿using System.Windows.Controls;

namespace VirtualPaging
{
    public partial class MainPage : UserControl
    {
        public MainPage()
        {
            InitializeComponent();

            Loaded += delegate
            {
                var viewModel = new MainViewModel();

                // auto-scroll log
                this.logEntriesListBox.ItemContainerGenerator.ItemsChanged += delegate
                {
                    var lastItem = this.logEntriesListBox.Items.Count;

                    if (lastItem == 0)
                    {
                        return;
                    }

                    this.logEntriesListBox.ScrollIntoView(this.logEntriesListBox.Items[lastItem - 1]);
                };

                this.DataContext = viewModel;
            };
        }
    }
}