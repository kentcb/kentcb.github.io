﻿namespace VirtualPaging
{
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.ComponentModel;
    using System.Threading;
    using System.Windows.Input;

    public class MainViewModel : ViewModel
    {
        private readonly DelegateCommand loadPeopleCommand;
        private readonly ICollection<string> logEntries;
        private ICollectionView peopleCollection;
        private bool isLoadingPeople;
        private int totalNumberOfPeople;
        private int pageSize;

        public MainViewModel()
        {
            this.loadPeopleCommand = new DelegateCommand(this.OnLoadPeople, o => !this.isLoadingPeople);
            this.logEntries = new ObservableCollection<string>();
            this.totalNumberOfPeople = 1000;
            this.pageSize = 20;
        }

        public ICommand LoadPeopleCommand
        {
            get { return this.loadPeopleCommand; }
        }

        public ICollection<string> LogEntries
        {
            get { return this.logEntries; }
        }

        public int TotalNumberOfPeople
        {
            get { return this.totalNumberOfPeople; }
            set
            {
                if (this.totalNumberOfPeople != value)
                {
                    this.totalNumberOfPeople = value;
                    this.OnPropertyChanged(() => this.TotalNumberOfPeople);
                }
            }
        }

        public int PageSize
        {
            get { return this.pageSize; }
            set
            {
                if (this.pageSize != value)
                {
                    this.pageSize = value;
                    this.OnPropertyChanged(() => this.PageSize);
                }
            }
        }

        public ICollectionView People
        {
            get { return this.peopleCollection; }
            private set
            {
                if (this.peopleCollection != value)
                {
                    this.peopleCollection = value;
                    this.OnPropertyChanged(() => this.People);
                }
            }
        }

        private void OnLoadPeople(object state)
        {
            this.LogEntries.Clear();
            this.LogEntries.Add("Loading " + this.TotalNumberOfPeople + " people...");
            this.isLoadingPeople = true;
            this.loadPeopleCommand.InvalidateCanExecute();

            // do the work on a background thread (I'm trying to be as realistic as practical)
            ThreadPool.QueueUserWorkItem(delegate
            {
                // simulate initial pause to determine number of people - here you would actually query the server or whatever
                // there is also an overload to LazyAsyncCollectionView<T> that allows you to specify the first page of results,
                // which is useful if your server-side function can get the total count and a page in one shot
                Thread.Sleep(250);

                Dispatcher.BeginInvoke(delegate
                {
                    this.People = new LazyAsyncCollectionView<PersonViewModel>(this.TotalNumberOfPeople, this.PageSize, this.GetPage);
                    this.isLoadingPeople = false;
                    this.loadPeopleCommand.InvalidateCanExecute();
                    this.LogEntries.Add("...loaded.");
                });
            });
        }

        private IEnumerable<PersonViewModel> GetPage(int pageNumber)
        {
            var threadId = Thread.CurrentThread.ManagedThreadId;

            Dispatcher.BeginInvoke(delegate
            {
                this.LogEntries.Add("Getting page #" + pageNumber + " on thread #" + threadId + "...");
            });

            // simulate a slow call to the server or whatever
            Thread.Sleep(1500);

            // generate some fake peeps for the page
            for (var i = pageNumber * pageSize; i < (pageNumber + 1) * pageSize; ++i)
            {
                if (i == totalNumberOfPeople)
                {
                    yield break;
                }

                yield return new PersonViewModel("First Name " + i, "Second Name " + i);
            }

            Dispatcher.BeginInvoke(delegate
            {
                this.LogEntries.Add("...got page " + pageNumber + ".");
            });
        }
    }
}