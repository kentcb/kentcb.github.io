﻿namespace VirtualPaging
{
    using System;
    using System.Threading;
    using System.Windows;
    using System.Windows.Input;
    using System.Windows.Threading;
    
    public abstract class Command : ICommand
    {
        public event EventHandler CanExecuteChanged;

        private Dispatcher Dispatcher
        {
            get { return Application.Current.RootVisual.Dispatcher; }
        }

        public abstract bool CanExecute(object parameter);

        public abstract void Execute(object parameter);

        protected virtual void OnCanExecuteChanged()
        {
            if (!this.Dispatcher.CheckAccess())
            {
                this.Dispatcher.BeginInvoke((ThreadStart)this.OnCanExecuteChanged);
            }
            else
            {
                var handler = this.CanExecuteChanged;

                if (handler != null)
                {
                    handler(this, EventArgs.Empty);
                }
            }
        }
    }
}