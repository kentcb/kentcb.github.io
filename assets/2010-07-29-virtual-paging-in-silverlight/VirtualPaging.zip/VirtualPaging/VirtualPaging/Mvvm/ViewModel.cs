﻿namespace VirtualPaging
{
    using System;
    using System.ComponentModel;
    using System.Linq.Expressions;
    using System.Windows.Threading;

    public abstract class ViewModel : INotifyPropertyChanged
    {
        private static Dispatcher dispatcher;

        protected ViewModel()
        {
        }

        public event PropertyChangedEventHandler PropertyChanged;

        protected Dispatcher Dispatcher
        {
            get
            {
                return dispatcher;
            }
        }

        public static void SetDispatcher(Dispatcher dispatcher)
        {
            ViewModel.dispatcher = dispatcher;
        }

        protected virtual void OnPropertyChanged<T>(Expression<Func<T>> propertyExpression)
        {
            var memberExpression = (MemberExpression)propertyExpression.Body;
            var propertyName = memberExpression.Member.Name;
            this.OnPropertyChanged(propertyName);
        }

        protected virtual void OnPropertyChanged(PropertyChangedEventArgs e)
        {
            var handler = this.PropertyChanged;

            if (handler != null)
            {
                handler(this, e);
            }
        }

        protected void OnPropertyChanged(string propertyName)
        {
            this.OnPropertyChanged(new PropertyChangedEventArgs(propertyName));
        }
    }
}