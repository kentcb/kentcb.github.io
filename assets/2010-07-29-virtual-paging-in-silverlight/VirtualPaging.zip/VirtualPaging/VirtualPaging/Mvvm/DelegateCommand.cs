﻿namespace VirtualPaging
{
    using System;

    public class DelegateCommand : Command
    {
        private readonly Predicate<object> canExecute;
        private readonly Action<object> execute;
        private bool oldCanExecuteValue;

        public DelegateCommand(Action<object> execute)
            : this(execute, null)
        {
        }

        public DelegateCommand(Action<object> execute, Predicate<object> canExecute)
        {
            this.execute = execute;
            this.canExecute = canExecute;
        }

        public override bool CanExecute(object parameter)
        {
            if (this.canExecute == null)
            {
                return true;
            }

            var newCanExecuteValue = canExecute(parameter);

            if (oldCanExecuteValue != newCanExecuteValue)
            {
                oldCanExecuteValue = newCanExecuteValue;

                this.OnCanExecuteChanged();
            }

            return oldCanExecuteValue;
        }

        public override void Execute(object parameter)
        {
            this.execute(parameter);
        }

        public void InvalidateCanExecute()
        {
            this.OnCanExecuteChanged();
        }
    }
}